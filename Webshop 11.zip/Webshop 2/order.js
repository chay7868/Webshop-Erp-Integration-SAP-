// =======================
// Configuration
// =======================
const API_BASE = "http://localhost:5050/api";

console.log("✅ orders.js loaded");

// =======================
// Initialization
// =======================
document.addEventListener("DOMContentLoaded", () => {
  console.log("✅ DOM ready on orders page");
  loadOrders();
  setupOrderPageNavigation();
});

// =======================
// Load Orders from Backend
// =======================
async function loadOrders() {
  const ordersList = document.getElementById("orders-list");

  if (!ordersList) {
    console.error("❌ orders-list element not found in DOM");
    return;
  }

  const token = localStorage.getItem("token");
  console.log("🔑 Token present on orders page?", !!token);

  // Require login
  if (!token) {
    ordersList.innerHTML = `
      <div class="no-orders">
        <i class="fas fa-exclamation-circle"></i>
        <h3>Please Login to View Orders</h3>
        <p>You need to be logged in to see your order history.</p>
        <a href="index.html" class="btn">Go to Homepage</a>
      </div>
    `;
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/orders/my`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("🔄 /orders/my status:", res.status);

    if (res.status === 401) {
      ordersList.innerHTML = `
        <div class="no-orders">
          <i class="fas fa-lock"></i>
          <h3>Session expired</h3>
          <p>Please log in again to see your orders.</p>
          <a href="index.html" class="btn">Login</a>
        </div>`;
      return;
    }

    const json = await res.json();
    console.log("📦 /orders/my payload:", json);

    // Support {success:true,data:[...]} or just [...]
    const userOrders = json.data || json.orders || json;

    if (!Array.isArray(userOrders) || userOrders.length === 0) {
      ordersList.innerHTML = `
        <div class="no-orders">
          <i class="fas fa-shopping-bag"></i>
          <h3>No Orders Yet</h3>
          <p>You haven't placed any orders yet. Start shopping to see your order history here!</p>
          <a href="index.html" class="btn">Start Shopping</a>
        </div>`;
      return;
    }

    // Sort newest first
    userOrders.sort(
      (a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)
    );

    ordersList.innerHTML = userOrders.map(createOrderCard).join("");
  } catch (err) {
    console.error("Error loading orders:", err);
    ordersList.innerHTML = `
      <div class="no-orders">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>Error loading orders</h3>
        <p>Could not connect to the server. Please try again later.</p>
      </div>`;
  }
}

// =======================
// Order Card Display
// =======================
function createOrderCard(order) {
  const statusClass = getStatusClass(order.status);
  const items = order.items || [];
  const itemsCount = items.reduce(
    (total, i) => total + (i.qty || i.quantity || 0),
    0
  );

  const orderId = order._id || order.orderNumber || "Unknown";
  const created = order.createdAt || order.date || new Date().toISOString();

  return `
    <div class="order-card" data-order-id="${orderId}">
      <div class="order-header">
        <div class="order-info">
          <div class="order-number">Order #${String(orderId).slice(-6)}</div>
          <div class="order-date">Placed on ${new Date(
            created
          ).toLocaleString()}</div>
        </div>
        <div class="order-status ${statusClass}">${
    order.status || "Processing"
  }</div>
      </div>

      <div class="order-details">
        <div class="order-items">
          <h3>Order Items (${itemsCount})</h3>
          ${items
            .map((item) => {
              const qty = item.qty || item.quantity || 0;
              const price =
                item.priceAtPurchase || item.price || item.unitPrice || 0;

              const p = item.productId || {};
              const name =
                p.name || p.productName || item.name || "Product";
              const img =
                p.image ||
                p.productImage ||
                "https://cdn-icons-png.flaticon.com/512/1046/1046765.png";

              return `
            <div class="order-item">
              <img src="${img}" alt="${name}" class="item-image">
              <div class="item-details">
                <div class="item-name">${name}</div>
                <div class="item-price">$${price.toFixed(2)} each</div>
                <div class="item-quantity">Quantity: ${qty}</div>
              </div>
              <div class="item-total">$${(price * qty).toFixed(2)}</div>
            </div>`;
            })
            .join("")}
        </div>

        <div class="order-actions">
          <button class="btn btn-secondary" onclick="viewOrderDetails('${orderId}')">
            <i class="fas fa-eye"></i> View Details
          </button>
          ${
            (order.status || "").toLowerCase() === "processing"
              ? `
          <button class="btn btn-danger" onclick="cancelOrder('${orderId}')">
            <i class="fas fa-times"></i> Cancel
          </button>`
              : ""
          }
          <button class="btn btn-primary" onclick="reorderItems('${orderId}')">
            <i class="fas fa-redo"></i> Reorder
          </button>
        </div>
      </div>

      <div class="order-total">
        <span>Total Amount:</span>
        <span>$${(order.total || 0).toFixed(2)}</span>
      </div>
    </div>`;
}

function getStatusClass(status) {
  switch (status && status.toLowerCase()) {
    case "processing":
      return "status-processing";
    case "shipped":
      return "status-shipped";
    case "delivered":
      return "status-delivered";
    case "cancelled":
      return "status-cancelled";
    default:
      return "status-processing";
  }
}

// =======================
// Order Actions
// =======================
async function cancelOrder(orderId) {
  const token = localStorage.getItem("token");
  if (!token) return showNotification("Please login first", "error");

  if (!confirm("Are you sure you want to cancel this order?")) return;

  try {
    const res = await fetch(`${API_BASE}/orders/${orderId}/cancel`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (res.ok) {
      showNotification("Order cancelled successfully!", "success");
      loadOrders();
    } else {
      showNotification("Failed to cancel order", "error");
    }
  } catch (err) {
    console.error(err);
    showNotification("Error cancelling order", "error");
  }
}

async function reorderItems(orderId) {
  const token = localStorage.getItem("token");
  if (!token) return showNotification("Please login first", "error");

  try {
    const res = await fetch(`${API_BASE}/orders/${orderId}/reorder`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (res.ok) {
      showNotification("Items added to cart successfully!", "success");
      setTimeout(() => (window.location.href = "index.html"), 1500);
    } else {
      showNotification("Failed to reorder items", "error");
    }
  } catch (err) {
    console.error(err);
    showNotification("Server error", "error");
  }
}

function viewOrderDetails(orderId) {
  alert('You clicked "View Details" for Order #' + orderId);
}

// =======================
// Navigation + UI
// =======================
function setupOrderPageNavigation() {
  const ordersBtn = document.querySelector("#orders-btn");
  if (ordersBtn) ordersBtn.classList.add("active");
  updateOrderPageUI();
}

function updateOrderPageUI() {
  const loginBtn = document.querySelector("#login-btn");
  const token = localStorage.getItem("token");
  if (!loginBtn) return;

  const icon = loginBtn.querySelector("i");
  if (token) {
    icon.className = "fas fa-sign-out-alt";
    loginBtn.title = "Logout";
    loginBtn.onclick = logout;
  } else {
    icon.className = "fas fa-user";
    loginBtn.title = "Login";
    loginBtn.onclick = () => (window.location.href = "index.html");
  }
}

// =======================
// Notifications + Logout
// =======================
function showNotification(message, type = "success") {
  const existing = document.querySelector(".notification");
  if (existing) existing.remove();

  const notification = document.createElement("div");
  notification.className = "notification " + type;
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => notification.remove(), 3000);
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("currentUser");
  showNotification("Logged out successfully!", "success");
  setTimeout(() => (window.location.href = "index.html"), 1000);
}
