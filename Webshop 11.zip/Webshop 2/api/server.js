require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const path = require("path");
const fs = require("fs");
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const { sendOrderToERP } = require("./erpClient");

const app = express();

// =======================
// Middleware
// =======================
app.use(express.json());
app.use(cookieParser());
app.use(
  cors({
    origin: [
      'http://127.0.0.1:5500',
      'http://localhost:5500',
      'http://localhost:3000',
      'http://127.0.0.1:3000'
    ],
    credentials: true
  })
);

// =======================
// ERP Import Files Storage Setup
// =======================
// Folder where we store ERP import snapshots
const IMPORT_DIR = path.join(__dirname, "erp_imports");
if (!fs.existsSync(IMPORT_DIR)) {
  fs.mkdirSync(IMPORT_DIR);
}

// Serve the ERP imports folder statically
app.use("/erp-imports", express.static(IMPORT_DIR));

// Serve the upload page
app.get('/upload', (req, res) => {
  res.sendFile(path.join(__dirname, 'upload.html'));
});

// Serve the system logs page
app.get('/admin/logs', (req, res) => {
  res.sendFile(path.join(__dirname, 'logs.html'));
});

// =======================
// MongoDB Connection
// =======================
mongoose
  .connect(
    "mongodb+srv://chaychikkala_db_user:nogbocB5xTyfx2Ms@cluster0.ehzxibc.mongodb.net/?appName=Cluster0"
  )
  .then(() => console.log("✅ MongoDB connected successfully"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));

// =======================
// ERP Configuration - WITH AUTHENTICATION
// =======================
const ERP_BASE_URL = "http://localhost:4004";
const ERP_PRODUCTS_API = `${ERP_BASE_URL}/odata/v4/simple-erp/Products`;
const ERP_USERNAME = process.env.ERP_USERNAME || "admin";
const ERP_PASSWORD = process.env.ERP_PASSWORD || "admin";

// Create Basic Auth header
const ERP_AUTH_HEADER = "Basic " + Buffer.from(`${ERP_USERNAME}:${ERP_PASSWORD}`).toString("base64");

// For create/update/delete operations
const ERP_CREATE_PRODUCT_API = `${ERP_BASE_URL}/odata/v4/simple-erp/Products`;
const ERP_UPDATE_PRODUCT_API = `${ERP_BASE_URL}/odata/v4/simple-erp/Products`;
const ERP_DELETE_PRODUCT_API = `${ERP_BASE_URL}/odata/v4/simple-erp/Products`;

// =======================
// Data Transformation Layer for OData API
// =======================

// OData / CSV → MongoDB format (robust header handling)
const transformToMongoDB = (erpProduct = {}) => {
  // Normalise keys like "Product Name", "product_name", "Product Name "
  const normalizeKey = (k) => k.toLowerCase().replace(/[\s_]+/g, "");

  const keys = Object.keys(erpProduct);
  const lookup = (aliases) => {
    const aliasSet = new Set(aliases.map(normalizeKey));
    for (const key of keys) {
      if (aliasSet.has(normalizeKey(key))) {
        return erpProduct[key];
      }
    }
    return undefined;
  };

  // --- Price ---
  let rawPrice = lookup(["price", "productprice", "erpprice"]);
  if (typeof rawPrice === "string") {
    rawPrice = rawPrice.replace(/[^\d.,-]/g, "").replace(",", ".");
  }
  const price = parseFloat(rawPrice || 0) || 0;

  // --- Stock ---
  let rawStock = lookup(["stock", "productstock", "erpstock"]) ?? 0;
  const stock = Number(rawStock) || 0;

  // --- Name / Description ---
  const name =
    lookup(["name", "productname", "product_name", "product name"]) || "Unknown";

  const description =
    lookup([
      "description",
      "productdescription",
      "product_description",
      "product description",
    ]) || "No description";

  // --- ERP Product ID (if present) ---
  let erpProductId = lookup([
    "id",
    "productid",
    "product_id",
    "product id",
    "erpproductid",
  ]);

  if (typeof erpProductId === "string" && erpProductId.trim() === "") {
    erpProductId = undefined;
  }

  const result = {
    productName: name,
    productPrice: String(price),
    productDescription: description,
    erpProductId,
    productStock: String(stock),
    erpPrice: price,
    erpStock: stock,
  };

  console.log("🧪 transformToMongoDB result:", result);
  return result;
};

// MongoDB → OData format - CORRECTED FOR SAP CAP
const transformToERP = (mongoProduct) => {
  const price = parseFloat(mongoProduct.productPrice) || 0;

  return {
    productID: `WEB_${mongoProduct.productName.toUpperCase().replace(/\s+/g, '')}_${Date.now()}`,
    name: mongoProduct.productName,
    description: mongoProduct.productDescription || "From Web Shop",
    price: price,
    stock: 0, // ERP manages all stock - start with 0
    currency_code: "EUR"
  };
};

// =======================
// REAL-TIME ERP RPC SERVICES
// =======================

// Get real-time stock from ERP - with retry
// Get real-time stock from ERP - with retry + logging
async function getERPStock(erpProductId) {
  try {
    const response = await fetchWithRetry(
      `${ERP_PRODUCTS_API}('${erpProductId}')`,
      {
        headers: {
          'Accept': 'application/json',
          'Authorization': ERP_AUTH_HEADER
        }
      },
      3,   // retries
      300  // delay ms
    );

    const product = await response.json();
    return product.stock || 0;
  } catch (error) {
    console.error(
      `❌ Stock RPC failed for ERP product ${erpProductId}:`,
      error.message
    );

    // 🔴 Log **every** failed stock RPC
    await logSystemError({
      tag: "critical",
      code: "STOCK_CHECK_FAILED",
      message: `Stock RPC failed for ERP product ${erpProductId}: ${error.message}`,
      context: { erpProductId },
    });

    throw error;
  }
}

// Get real-time stock from ERP for multiple products - with retry
async function getBulkERPStock(productSKUs) {
  try {
    console.log('📦 Fetching REAL stock from ERP for:', productSKUs);

    const stockData = {};

    // Fetch real stock for each product from ERP
    for (const sku of productSKUs) {
      try {
        const response = await fetchWithRetry(
          `${ERP_PRODUCTS_API}('${sku}')`,
          {
            headers: {
              'Accept': 'application/json',
              'Authorization': ERP_AUTH_HEADER
            }
          },
          3,
          300
        );

        const product = await response.json();
        stockData[sku] = product.stock || 0;
        console.log(`✅ Real stock for ${sku}: ${stockData[sku]}`);
      } catch (productError) {
        console.error(`❌ Error fetching stock for ${sku}:`, productError.message);
        stockData[sku] = 0; // Default to 0 on error
      }
    }

    return stockData;
  } catch (error) {
    console.error("❌ Bulk ERP stock fetch failed:", error);

    // 🔴 Log a single entry for this bulk failure
    await logSystemError({
      tag: "critical",
      code: "STOCK_CHECK_FAILED",
      message: `Bulk stock check failed: ${error.message}`,
      context: { productSKUs },
    });

    // Return fallback stock data (so frontend can still show "Out of Stock")
    const fallbackStock = {};
    productSKUs.forEach((sku) => {
      fallbackStock[sku] = 0; // Default to out of stock
    });
    return fallbackStock;
  }
}


// Generic fetch with retry helper
async function fetchWithRetry(url, options = {}, retries = 3, delayMs = 500) {
  let lastError;

  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) {
        throw new Error(`HTTP ${res.status} ${res.statusText}`);
      }
      return res;
    } catch (err) {
      lastError = err;
      console.warn(
        `⚠️ fetchWithRetry failed (attempt ${attempt + 1}/${retries}) for ${url}:`,
        err.message
      );

      if (attempt < retries - 1) {
        await new Promise((r) => setTimeout(r, delayMs));
      }
    }
  }

  throw lastError;
}

function toDecimal2(value) {
  const num = Number(value) || 0;
  // round to 2 decimals and convert back to Number
  return Number(num.toFixed(2));
}

// Create order directly in ERP - WITH ORDER ITEMS & RETRY
async function createERPOrder(orderData, items = []) {
  try {
    console.log("🔄 Creating order in ERP as single source of truth...");

    // Build inline items
    const inlineItems = [];
    const itemErrors = [];

    for (const item of items) {
      try {
        const product = await Product.findById(item.productId);
        if (!product || !product.erpProductId) {
          itemErrors.push(`Product ${item.productId} not synced with ERP`);
          continue;
        }

        inlineItems.push({
          product_ID: product.erpProductId,
          quantity: item.qty,
          itemAmount: toDecimal2(item.priceAtPurchase * item.qty),
          currency_code: "EUR"
        });
      } catch (e) {
        itemErrors.push(`Item error: ${e.message}`);
      }
    }

    const erpOrder = {
      customer_ID: orderData.erpCustomerId,
      orderDate: new Date().toISOString().split('T')[0],
      orderAmount: toDecimal2(orderData.total),
      currency_code: "EUR",
      orderStatus_status: 10,
      items: inlineItems
    };

    console.log("📤 Sending ORDER (header + items) to ERP:", JSON.stringify(erpOrder, null, 2));

    const orderResponse = await fetchWithRetry(
      `${ERP_BASE_URL}/odata/v4/simple-erp/Orders`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": ERP_AUTH_HEADER
        },
        body: JSON.stringify(erpOrder)
      },
      3,
      500
    );

    const orderResult = await orderResponse.json();
    const orderId = orderResult.ID;

    console.log("✅ Order created in ERP with items:", orderId);

    return {
      success: true,
      orderId,
      createdItems: inlineItems.length,
      itemErrors
    };

  } catch (error) {
    console.error("❌ ERP Order creation failed:", error.message);
    throw error;
  }
}

// =======================
// Schemas
// =======================
const { Schema, model } = mongoose;

const UserSchema = new Schema(
  {
    email: { type: String, unique: true, required: true },
    passwordHash: { type: String, required: true },
    name: { type: String },
    erpCustomerId: { type: String },   // ERP Customers.ID
  },
  { timestamps: true }
);

const OrderSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    erpOrderId: { type: String }, // Reference to ERP order
    items: [
      {
        productId: String,
        qty: Number,
        priceAtPurchase: Number,
      },
    ],
    total: Number,
    status: { type: String, default: 'created' },
  },
  { timestamps: true }
);

const ProductSchema = new Schema(
  {
    productName: { type: String, required: true },
    productPrice: { type: String, required: true },
    productDescription: { type: String, required: true },

    // 🔽 NEW FIELDS (snapshot from ERP)
    productStock: { type: String, default: "0" }, // your old local stock field
    erpProductId: { type: String },
    erpStock: { type: Number, default: 0 },
    erpPrice: { type: Number, default: 0 },
  },
  { timestamps: true }
);


const SystemErrorLogSchema = new Schema(
  {
    tag: { type: String, default: "minor" },      // e.g. 'minor', 'critical'
    code: { type: String, required: true },       // e.g. 'OUT_OF_STOCK'
    message: { type: String, required: true },    // human-readable
    context: { type: Schema.Types.Mixed },        // optional extra info
  },
  { timestamps: true }
);

const User = model("User", UserSchema);
const Order = model("Order", OrderSchema);
const Product = model("Products", ProductSchema);
const SystemErrorLog = model("SystemErrorLog", SystemErrorLogSchema);

// =======================
// Helpers
// =======================
function makeToken(user) {
  return jwt.sign(
    { uid: user._id, email: user.email },
    process.env.JWT_SECRET || "fallback-secret",
    { expiresIn: "7d" }
  );
}

function auth(req, res, next) {
  const bearer = (req.header("Authorization") || "").replace("Bearer ", "");
  const token = req.cookies.token || bearer;
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || "fallback-secret");
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

async function logSystemError({ tag = "minor", code, message, context = {} }) {
  try {
    await SystemErrorLog.create({ tag, code, message, context });
  } catch (e) {
    console.error("❌ Failed to save system error log:", e.message);
  }
}

async function ensureERPCustomerForUser(user) {
  // If we already have a mapped ERP customer, reuse it
  if (user.erpCustomerId) {
    return user.erpCustomerId;
  }

  // Create a new customer in ERP
  const customerPayload = {
    name: user.name || user.email,
    email: user.email,              // 👈 REQUIRED in your CAP model
    // add more fields here if your Customers entity has other NOT NULL fields
    // e.g. city, country, etc.
  };

  const resp = await fetch(`${ERP_BASE_URL}/odata/v4/simple-erp/Customers`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": ERP_AUTH_HEADER,
    },
    body: JSON.stringify(customerPayload),
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Failed to create ERP customer: ${resp.status} ${text}`);
  }

  const data = await resp.json();
  const erpId = data.ID; // your Customers entity uses ID

  user.erpCustomerId = erpId;
  await user.save();

  return erpId;
}


// =======================
// Enhanced Product Add/Update with Data Validation & ERP Sync
// =======================
app.post("/api/product/addProduct", async (req, res) => {
  try {
    const { productName, productPrice, productStock, productDescription } = req.body;

    // 1. First create in MongoDB
    const validatedProduct = {
      productName,
      productPrice: String(productPrice),
      productDescription,
    };

    const mongoProduct = await Product.create(validatedProduct);

    // 2. Then sync to ERP
    try {
      const erpProductData = transformToERP(mongoProduct);

      const erpResponse = await fetch(ERP_CREATE_PRODUCT_API, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": ERP_AUTH_HEADER
        },
        body: JSON.stringify(erpProductData),
      });

      if (erpResponse.ok) {
        const erpResult = await erpResponse.json();
        // Update MongoDB with ERP ID
        await Product.findByIdAndUpdate(mongoProduct._id, {
          erpProductId: erpResult.ID || erpResult.ProductID,
        });

        console.log(`✅ Product synced to ERP: ${productName}`);
      }
    } catch (erpError) {
      console.warn(`⚠️ Product created in MongoDB but ERP sync failed: ${erpError.message}`);
    }

    res.json({
      success: true,
      msg: "Product added successfully",
      data: mongoProduct,
    });
  } catch (error) {
    console.error("❌ Error adding product:", error);
    res.status(500).json({
      success: false,
      msg: "Server error",
      error: error.message,
    });
  }
});

app.put("/api/product/updateProduct/:id", async (req, res) => {
  try {
    const updateData = { ...req.body };
    if (typeof updateData.productPrice === "number")
      updateData.productPrice = String(updateData.productPrice);

    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );

    if (!updatedProduct) {
      return res.status(404).json({
        success: false,
        msg: "Product not found",
      });
    }

    // Sync update to ERP if product has ERP ID
    if (updatedProduct.erpProductId) {
      try {
        const erpProductData = transformToERP(updatedProduct);

        await fetch(`${ERP_UPDATE_PRODUCT_API}(${updatedProduct.erpProductId}')`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "Authorization": ERP_AUTH_HEADER
          },
          body: JSON.stringify(erpProductData),
        });

        console.log(`✅ Product updated in ERP: ${updatedProduct.productName}`);
      } catch (erpError) {
        console.warn(`⚠️ Product updated in MongoDB but ERP sync failed: ${erpError.message}`);
      }
    }

    res.json({
      success: true,
      msg: "Product updated successfully",
      data: updatedProduct,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      msg: "Server error",
    });
  }
});

// Add this cleanup endpoint to your server.js around line 300-350
app.get("/api/erp/cleanup-orphaned-products", async (_req, res) => {
  try {
    console.log("🧹 Cleaning up orphaned products (exist in MongoDB but not in ERP)...");

    // Get all ERP product IDs
    const erpResponse = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });
    const erpData = await erpResponse.json();
    const erpProductIds = erpData.value.map(p => p.ID);

    console.log(`📦 ERP has ${erpProductIds.length} products`);

    // Find MongoDB products that don't exist in ERP
    const allMongoProducts = await Product.find({});
    const orphanedProducts = allMongoProducts.filter(p =>
      p.erpProductId && !erpProductIds.includes(p.erpProductId)
    );

    console.log(`🔍 Found ${orphanedProducts.length} orphaned products`);

    // Delete orphaned products
    const result = await Product.deleteMany({
      erpProductId: { $in: orphanedProducts.map(p => p.erpProductId) }
    });

    console.log(`✅ Deleted ${result.deletedCount} orphaned products`);

    res.json({
      success: true,
      message: `Deleted ${result.deletedCount} orphaned products`,
      deletedCount: result.deletedCount,
      orphanedProducts: orphanedProducts.map(p => p.productName)
    });
  } catch (error) {
    console.error("❌ Cleanup failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =======================
// Routes
// =======================
app.get("/api/health", (_req, res) => res.json({ ok: true }));

// ✅ ERP Health Check - WITH AUTHENTICATION
app.get("/api/erp/health", async (_req, res) => {
  try {
    console.log("🔗 Testing ERP connection to:", ERP_PRODUCTS_API);
    console.log("🔑 Using credentials:", ERP_USERNAME, ":***");

    const response = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (!response.ok) {
      throw new Error(`ERP Health Failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log("✅ ERP Health Check - Response received");

    res.json({
      ok: true,
      productsCount: data.value ? data.value.length : 'unknown',
      message: 'ERP connected successfully with authentication'
    });
  } catch (err) {
    console.error("❌ ERP Health Error:", err.message);
    res.status(500).json({
      ok: false,
      error: err.message,
      erpUrl: ERP_PRODUCTS_API
    });
  }
});


// Test if Orders endpoint exists
app.get("/api/debug/erp-orders", async (_req, res) => {
  try {
    console.log("🔗 Testing Orders endpoint...");
    const response = await fetch(`${ERP_BASE_URL}/odata/v4/simple-erp/Orders`, {
      headers: {
        'Accept': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    console.log(`📊 Orders endpoint status: ${response.status} ${response.statusText}`);

    if (response.ok) {
      const data = await response.json();
      res.json({
        success: true,
        ordersCount: data.value ? data.value.length : 'unknown',
        data: data
      });
    } else {
      const errorText = await response.text();
      res.status(500).json({
        success: false,
        error: `Orders endpoint failed: ${response.status} - ${errorText}`,
        status: response.status,
        statusText: response.statusText
      });
    }
  } catch (error) {
    console.error("Orders debug failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ✅ NEW: Debug MongoDB products with their ERP IDs
app.get("/api/debug/mongo-products", async (_req, res) => {
  try {
    const products = await Product.find({});

    console.log("📦 MongoDB Products with ERP IDs:");
    products.forEach(p => {
      console.log(`- ${p.productName}: MongoDB ID: ${p._id}, ERP ID: ${p.erpProductId || 'NOT SYNCED'}`);
    });

    res.json({
      success: true,
      products: products.map(p => ({
        name: p.productName,
        mongoId: p._id,
        erpId: p.erpProductId,
        hasErpId: !!p.erpProductId
      })),
      count: products.length
    });
  } catch (error) {
    console.error("Debug failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});
// ✅ Debug: Get raw ERP data to understand structure
app.get("/api/erp/debug-products", async (_req, res) => {
  try {
    console.log("🔍 Fetching ERP data from:", ERP_PRODUCTS_API);

    const erpResponse = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (!erpResponse.ok) {
      throw new Error(`ERP responded with status: ${erpResponse.status} ${erpResponse.statusText}`);
    }

    const erpData = await erpResponse.json();

    console.log("📦 ERP Raw Data Structure:", JSON.stringify(erpData, null, 2));

    res.json({
      success: true,
      erpUrl: ERP_PRODUCTS_API,
      rawData: erpData,
      productsCount: erpData.value ? erpData.value.length : 'unknown',
      sampleProduct: erpData.value && erpData.value.length > 0 ? erpData.value[0] : erpData,
      dataType: 'odata'
    });
  } catch (error) {
    console.error("❌ Debug failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      erpUrl: ERP_PRODUCTS_API
    });
  }
});

// Debug: Check available customers
app.get("/api/debug/erp-customers", async (req, res) => {
  try {
    console.log("🔍 Checking ERP Customers...");

    const response = await fetch(`${ERP_BASE_URL}/odata/v4/simple-erp/Customers`, {
      headers: {
        'Accept': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (response.ok) {
      const data = await response.json();
      const customers = data.value || [];

      console.log("👥 Available customers:", customers.map(c => ({ id: c.ID, name: c.name })));

      res.json({
        success: true,
        customers: customers,
        count: customers.length
      });
    } else {
      const errorText = await response.text();
      res.status(500).json({
        success: false,
        error: `Customers endpoint failed: ${response.status}`,
        details: errorText
      });
    }
  } catch (error) {
    console.error("Customers check failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Debug: Check order status values
app.get("/api/debug/erp-order-status", async (req, res) => {
  try {
    console.log("🔍 Checking ERP Order Status...");

    const response = await fetch(`${ERP_BASE_URL}/odata/v4/simple-erp/OrderStatus`, {
      headers: {
        'Accept': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (response.ok) {
      const data = await response.json();
      const statuses = data.value || [];

      console.log("📊 Available order statuses:", statuses.map(s => ({ status: s.status, name: s.name })));

      res.json({
        success: true,
        orderStatus: statuses,
        count: statuses.length
      });
    } else {
      const errorText = await response.text();
      res.status(500).json({
        success: false,
        error: `OrderStatus endpoint failed: ${response.status}`,
        details: errorText
      });
    }
  } catch (error) {
    console.error("OrderStatus check failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Add this debug endpoint to see actual ERP products
app.get("/api/debug/erp-products", async (_req, res) => {
  try {
    const response = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (!response.ok) {
      throw new Error(`ERP responded with status: ${response.status}`);
    }

    const data = await response.json();

    // Show what products actually exist in ERP
    const products = data.value || [];
    console.log("📦 Actual ERP Products:", products.map(p => ({
      id: p.ID,
      name: p.name,
      stock: p.stock
    })));

    res.json({
      success: true,
      products: products,
      count: products.length
    });
  } catch (error) {
    console.error("Debug failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =======================
// ADMIN: System Error Logs
// =======================

// Get all logs (newest first)
app.get("/api/admin/logs", async (_req, res) => {
  try {
    const logs = await SystemErrorLog.find().sort({ createdAt: -1 }).lean();
    res.json({ success: true, logs });
  } catch (error) {
    console.error("❌ Failed to fetch system error logs:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch system error logs",
    });
  }
});

// Delete all logs
app.delete("/api/admin/logs", async (_req, res) => {
  try {
    const result = await SystemErrorLog.deleteMany({});
    res.json({
      success: true,
      deletedCount: result.deletedCount,
    });
  } catch (error) {
    console.error("❌ Failed to delete system error logs:", error);
    res.status(500).json({
      success: false,
      error: "Failed to delete system error logs",
    });
  }
});

// ✅ REAL-TIME: Sync Products from ERP to MongoDB - PRODUCT INFO ONLY (NO STOCK)
app.get("/api/erp/sync-from-erp", async (_req, res) => {
  try {
    console.log("🔄 Starting sync from ERP (product info only)...");

    const erpResponse = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (!erpResponse.ok) {
      throw new Error(`ERP responded with status: ${erpResponse.status} ${erpResponse.statusText}`);
    }

    const erpData = await erpResponse.json();
    const erpProducts = erpData.value || [];

    console.log(`📥 Found ${erpProducts.length} products in ERP`);

    let created = 0;
    let updated = 0;
    let errors = 0;
    const errorDetails = [];

    for (const erpProduct of erpProducts) {
      try {
        const mongoProductData = transformToMongoDB(erpProduct);

        console.log(`🔄 Processing: ${mongoProductData.productName}`);

        const existingProduct = await Product.findOne({
          $or: [
            { erpProductId: mongoProductData.erpProductId },
            { productName: mongoProductData.productName },
          ],
        });

        if (existingProduct) {
          await Product.findByIdAndUpdate(existingProduct._id, mongoProductData);
          updated++;
          console.log(`✅ Updated: ${mongoProductData.productName}`);
        } else {
          await Product.create(mongoProductData);
          created++;
          console.log(`✅ Created: ${mongoProductData.productName}`);
        }
      } catch (productError) {
        console.error(`❌ Error processing ERP product:`, productError.message);
        errors++;
        errorDetails.push({
          product: erpProduct.name || erpProduct.productName || 'Unknown',
          error: productError.message
        });
      }
    }

    console.log(`✅ Sync completed: ${created} created, ${updated} updated, ${errors} errors`);

    res.json({
      success: true,
      message: `Product info sync completed: ${created} created, ${updated} updated, ${errors} errors`,
      stats: { created, updated, errors, total: erpProducts.length },
      errors: errorDetails,
    });
  } catch (error) {
    console.error("❌ ERP sync failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ✅ FIXED: Export Products from MongoDB to ERP - WITH AUTHENTICATION
app.post("/api/erp/export-to-erp", async (_req, res) => {
  try {
    console.log("📤 Starting export to ERP REST API...");

    // Get products without ERP IDs
    const mongoProducts = await Product.find({
      erpProductId: { $exists: false }
    });

    console.log(`📦 Found ${mongoProducts.length} products to export`);

    let exported = 0;
    let errors = 0;
    const errorDetails = [];

    for (const mongoProduct of mongoProducts) {
      try {
        console.log(`🔄 Preparing: ${mongoProduct.productName}`);

        const erpProductData = transformToERP(mongoProduct);

        console.log("📤 Would send to ERP:", erpProductData);

        // Try to create in ERP
        const createResponse = await fetch(ERP_CREATE_PRODUCT_API, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": ERP_AUTH_HEADER
          },
          body: JSON.stringify(erpProductData),
        });

        if (createResponse.ok) {
          const erpResult = await createResponse.json();
          await Product.findByIdAndUpdate(mongoProduct._id, {
            erpProductId: erpResult.ID || erpResult.ProductID,
          });
          exported++;
          console.log(`✅ Exported: ${mongoProduct.productName}`);
        } else {
          throw new Error(`ERP responded with status: ${createResponse.status}`);
        }

      } catch (productError) {
        console.error(
          `❌ Error exporting product ${mongoProduct.productName}:`,
          productError.message
        );
        errorDetails.push({
          product: mongoProduct.productName,
          error: productError.message
        });
        errors++;
      }
    }

    console.log(`✅ Export completed: ${exported} exported, ${errors} errors`);

    res.json({
      success: true,
      message: `Export TO ERP completed: ${exported} exported, ${errors} errors`,
      stats: { exported, errors, total: mongoProducts.length },
      errors: errorDetails,
    });
  } catch (error) {
    console.error("❌ ERP export failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ✅ NEW: Import products from ERP with enhanced error handling AND FILE STORAGE
app.post("/api/erp/import-products", async (req, res) => {
  try {
    const { products, syncType = 'full_sync', source = 'erp_system' } = req.body;

    console.log(`🔄 Starting import from ${source}, type: ${syncType}`);

    let importedProducts = [];

    // If products array is provided in request, use it
    if (products && Array.isArray(products)) {
      console.log(`📥 Processing ${products.length} products from request body`);
      importedProducts = products;
    } else {
      // Otherwise fetch from ERP API (like your existing sync-from-erp)
      console.log("📥 Fetching products from ERP API...");
      const erpResponse = await fetch(ERP_PRODUCTS_API, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': ERP_AUTH_HEADER
        }
      });

      if (!erpResponse.ok) {
        throw new Error(`ERP responded with status: ${erpResponse.status}`);
      }

      const erpData = await erpResponse.json();
      importedProducts = erpData.value || [];
      console.log(`📥 Fetched ${importedProducts.length} products from ERP`);
    }

    let stats = {
      processed: 0,
      updated: 0,
      created: 0,
      errors: 0,
      total: importedProducts.length
    };

    const errors = [];
    const processedProducts = [];

    for (const erpProduct of importedProducts) {
      try {
        stats.processed++;

        const mongoProductData = transformToMongoDB(erpProduct);

        console.log(
          `🔄 Processing: ${mongoProductData.productName} (ERP ID: ${
            mongoProductData.erpProductId || "none"
          })`
        );

        // Find existing product:
        //   - if we have an ERP ID → match by erpProductId
        //   - else → match by productName
        let existingProduct = null;

        if (mongoProductData.erpProductId) {
          existingProduct = await Product.findOne({
            erpProductId: mongoProductData.erpProductId,
          });
        } else {
          existingProduct = await Product.findOne({
            productName: mongoProductData.productName,
          });
        }

        if (existingProduct) {
          console.log(
            `📝 Updating '${mongoProductData.productName}': ` +
            `old price=${existingProduct.productPrice}, ` +
            `new price=${mongoProductData.productPrice}`
          );

          // HARD overwrite with CSV/ERP values
          await Product.updateOne(
            { _id: existingProduct._id },
            { $set: mongoProductData }
          );

          stats.updated++;
          console.log(`✅ Updated in MongoDB: ${mongoProductData.productName}`);
        } else {
          const newProduct = await Product.create(mongoProductData);
          stats.created++;
          console.log(`✅ Created in MongoDB: ${mongoProductData.productName}`);
        }

        processedProducts.push({
          productName: mongoProductData.productName,
          status: existingProduct ? "updated" : "created",
          erpProductId: mongoProductData.erpProductId,
        });

      } catch (productError) {
        console.error(`❌ Error processing product:`, productError.message);
        stats.errors++;
        errors.push({
          product: erpProduct.name || erpProduct.productName || "Unknown",
          error: productError.message,
        });
      }
    }

    console.log(`✅ Import completed: ${stats.created} created, ${stats.updated} updated, ${stats.errors} errors`);

    // --- NEW: save imported ERP data as JSON and CSV snapshot ---
    try {
      if (importedProducts && importedProducts.length > 0) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        const baseName = `erp_import_${timestamp}`;

        // 1) Save JSON
        const jsonPath = path.join(IMPORT_DIR, `${baseName}.json`);
        fs.writeFileSync(jsonPath, JSON.stringify(importedProducts, null, 2), "utf8");

        // 2) Save CSV (simple conversion)
        const headers = ["name", "description", "price", "stock", "currency"];
        let csv = headers.join(",") + "\n";

        importedProducts.forEach(p => {
          // adapt field names to your ERP structure if needed
          const name = p.name || p.productName || "";
          const desc = p.description || p.productDescription || "";
          const price = p.price || p.productPrice || 0;
          const stock = p.stock || p.productStock || 0;
          const currency = p.currency_code || p.currency || "EUR";

          csv += [
            `"${String(name).replace(/"/g, '""')}"`,
            `"${String(desc).replace(/"/g, '""')}"`,
            price,
            stock,
            `"${currency}"`
          ].join(",") + "\n";
        });

        const csvPath = path.join(IMPORT_DIR, `${baseName}.csv`);
        fs.writeFileSync(csvPath, csv, "utf8");

        console.log(`📁 Saved ERP import snapshot as: ${baseName}.json and ${baseName}.csv`);
      }
    } catch (fileError) {
      console.warn("⚠️ Failed to save ERP import files:", fileError.message);
    }
    // --- END NEW PART ---

    res.json({
      success: true,
      message: `Import from ERP completed: ${stats.created} created, ${stats.updated} updated, ${stats.errors} errors`,
      stats: stats,
      processedProducts: processedProducts,
      errors: errors,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error("❌ Import failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      message: "Import from ERP failed"
    });
  }
});

// ✅ NEW: List saved ERP import files
app.get("/api/erp/import-files", (req, res) => {
  try {
    if (!fs.existsSync(IMPORT_DIR)) {
      return res.json({ success: true, files: [] });
    }

    const files = fs.readdirSync(IMPORT_DIR)
      .filter(f => f.endsWith(".json") || f.endsWith(".csv"))
      .map(filename => {
        const fullPath = path.join(IMPORT_DIR, filename);
        const stats = fs.statSync(fullPath);
        return {
          filename,
          size: stats.size,
          modified: stats.mtime
        };
      })
      .sort((a, b) => b.modified - a.modified); // newest first

    res.json({ success: true, files });
  } catch (err) {
    console.error("Error listing import files:", err);
    res.status(500).json({ success: false, error: "Failed to list ERP import files" });
  }
});

// ✅ NEW: Two-way bidirectional sync
app.post("/api/erp/sync-bidirectional", async (req, res) => {
  try {
    const {
      direction = 'both',
      options = {}
    } = req.body;

    console.log(`🔄 Starting bidirectional sync, direction: ${direction}`);

    const results = {
      export: null,
      import: null,
      success: true,
      message: ''
    };

    // Export to ERP (if needed)
    if (direction === 'both' || direction === 'export') {
      try {
        const exportResponse = await fetch(`http://localhost:${process.env.PORT || 5050}/api/erp/export-to-erp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        });
        results.export = await exportResponse.json();
      } catch (exportError) {
        results.export = { success: false, error: exportError.message };
      }
    }

    // Import from ERP (if needed)
    if (direction === 'both' || direction === 'import') {
      try {
        const importResponse = await fetch(`http://localhost:${process.env.PORT || 5050}/api/erp/import-products`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ syncType: 'bidirectional', source: 'erp_system' })
        });
        results.import = await importResponse.json();
      } catch (importError) {
        results.import = { success: false, error: importError.message };
      }
    }

    // Determine overall success
    const exportOk = !results.export || results.export.success;
    const importOk = !results.import || results.import.success;

    results.success = exportOk && importOk;
    results.message = `Bidirectional sync completed - Export: ${exportOk ? 'OK' : 'Failed'}, Import: ${importOk ? 'OK' : 'Failed'}`;

    console.log(`✅ Bidirectional sync completed: ${results.message}`);

    res.json(results);

  } catch (error) {
    console.error("❌ Bidirectional sync failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      message: "Bidirectional sync failed"
    });
  }
});

app.get('/api/products/export-csv', async (req, res) => {
  try {
    const products = await Product.find().lean();

    if (!products || products.length === 0) {
      return res.status(404).send("No products found.");
    }

    // CSV headers
    let csv = "name,description,price,stock,currency,erpProductId\n";

    // Convert each product to CSV row
    products.forEach(prod => {
      csv += [
        `"${prod.productName}"`,
        `"${prod.productDescription}"`,
        prod.productPrice,
        "0", // Stock managed by ERP only
        `"EUR"`,
        `"${prod.erpProductId || ''}"`
      ].join(",") + "\n";
    });

    // Set file headers so browser downloads it
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=products_export.csv");

    res.send(csv);

  } catch (error) {
    console.error("CSV export error:", error);
    res.status(500).send("Server error while exporting CSV.");
  }
});

// ✅ NEW: File-based import (for CSV/JSON files)
app.post("/api/erp/import-from-file", async (req, res) => {
  try {
    const { fileData, fileType = 'json', fileName } = req.body;

    console.log(`📁 Starting file import: ${fileName || 'unknown'}, type: ${fileType}`);

    let products = [];

    // Handle different file types
    if (fileType === 'json' && fileData) {
      if (Array.isArray(fileData)) {
        products = fileData;
      } else if (fileData.products && Array.isArray(fileData.products)) {
        products = fileData.products;
      } else if (fileData.value && Array.isArray(fileData.value)) {
        products = fileData.value;
      } else {
        throw new Error('Invalid JSON structure. Expected array of products or {products: [...]}');
      }
    } else if (fileType === 'csv' && fileData) {
      // Basic CSV parsing (you can enhance this)
      const lines = fileData.split('\n');
      const headers = lines[0].split(',').map(h => h.trim());

      products = lines.slice(1).filter(line => line.trim()).map(line => {
        const values = line.split(',').map(v => v.trim());
        const product = {};
        headers.forEach((header, index) => {
          product[header] = values[index] || '';
        });
        return product;
      });
    } else {
      throw new Error('Unsupported file type or missing file data');
    }

    console.log(`📊 Parsed ${products.length} products from file`);

    // Use the existing import logic
    const importResponse = await fetch(`http://localhost:${process.env.PORT || 5050}/api/erp/import-products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        products: products,
        syncType: 'file_import',
        source: fileName || 'uploaded_file'
      })
    });

    const importResult = await importResponse.json();

    res.json({
      success: importResult.success,
      message: `File import completed: ${importResult.message}`,
      fileInfo: {
        fileName: fileName,
        fileType: fileType,
        productsReceived: products.length
      },
      importResults: importResult
    });

  } catch (error) {
    console.error("❌ File import failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      message: "File import failed"
    });
  }
});

// ✅ NEW: Get sync configuration and status
app.get("/api/erp/sync-config", async (req, res) => {
  try {
    const mongoCount = await Product.countDocuments();
    const syncedCount = await Product.countDocuments({
      erpProductId: { $exists: true, $ne: null }
    });

    // Test ERP connection
    let erpAvailable = false;
    let erpCount = 0;

    try {
      const erpResponse = await fetch(ERP_PRODUCTS_API, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': ERP_AUTH_HEADER
        }
      });
      if (erpResponse.ok) {
        const erpData = await erpResponse.json();
        erpCount = erpData.value ? erpData.value.length : 0;
        erpAvailable = true;
      }
    } catch (erpError) {
      console.log("ERP connection test failed:", erpError.message);
    }

    res.json({
      success: true,
      config: {
        sync: {
          exportEnabled: true,
          importEnabled: true,
          bidirectionalEnabled: true,
          fileImportEnabled: true
        },
        endpoints: {
          export: '/api/erp/export-to-erp',
          import: '/api/erp/import-products',
          bidirectional: '/api/erp/sync-bidirectional',
          fileImport: '/api/erp/import-from-file',
          status: '/api/erp/sync-status'
        },
        status: {
          mongoProducts: mongoCount,
          syncedProducts: syncedCount,
          erpProducts: erpCount,
          erpAvailable: erpAvailable,
          syncHealth: erpAvailable ? 'healthy' : 'degraded'
        }
      }
    });
  } catch (error) {
    console.error("Sync config failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ✅ Update existing ERP products with MongoDB data
app.post("/api/erp/update-existing", async (_req, res) => {
  try {
    console.log("🔄 Starting to update existing ERP products...");

    // Get some products from MongoDB to use for updates
    const mongoProducts = await Product.find({}).limit(2);
    console.log(`📦 Found ${mongoProducts.length} products in MongoDB to use for updates`);

    let updated = 0;
    let errors = 0;
    const errorDetails = [];

    // Get existing ERP products
    const erpResponse = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    const erpData = await erpResponse.json();
    const existingErpProducts = erpData.value || [];
    console.log(`📥 Found ${existingErpProducts.length} existing products in ERP`);

    // Update each existing ERP product with MongoDB data
    for (let i = 0; i < existingErpProducts.length; i++) {
      try {
        const erpProduct = existingErpProducts[i];
        const mongoProduct = mongoProducts[i];

        if (!mongoProduct) {
          console.log("⚠️ No more MongoDB products to use for updates");
          break;
        }

        console.log(`🔄 Updating ERP product: ${erpProduct.name} with MongoDB data: ${mongoProduct.productName}`);

        const updateData = {
          name: mongoProduct.productName,
          description: mongoProduct.productDescription || "Updated from Web Shop",
          price: parseFloat(mongoProduct.productPrice) || 0,
          // Note: We don't update stock - ERP manages stock
        };

        console.log("📤 Update data:", updateData);

        const updateResponse = await fetch(`${ERP_UPDATE_PRODUCT_API}(${erpProduct.ID}')`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "Authorization": ERP_AUTH_HEADER
          },
          body: JSON.stringify(updateData),
        });

        if (updateResponse.ok) {
          // Also update MongoDB with the ERP ID
          await Product.findByIdAndUpdate(mongoProduct._id, {
            erpProductId: erpProduct.ID,
          });
          updated++;
          console.log(`✅ Updated: ${erpProduct.name} → ${mongoProduct.productName}`);
        } else {
          const errorText = await updateResponse.text();
          throw new Error(`Update failed: ${updateResponse.status} - ${errorText}`);
        }

      } catch (productError) {
        console.error(`❌ Error updating product:`, productError.message);
        errorDetails.push({
          product: existingErpProducts[i]?.name || 'Unknown',
          error: productError.message
        });
        errors++;
      }
    }

    console.log(`✅ Update completed: ${updated} updated, ${errors} errors`);

    res.json({
      success: true,
      message: `Update completed: ${updated} ERP products updated with MongoDB data, ${errors} errors`,
      stats: { updated, errors, total: existingErpProducts.length },
      errors: errorDetails,
    });
  } catch (error) {
    console.error("❌ Update failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ✅ Test data transformation
app.get("/api/erp/test-transform", async (req, res) => {
  try {
    // Get sample data from ERP
    const erpResponse = await fetch(ERP_PRODUCTS_API, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': ERP_AUTH_HEADER
      }
    });

    if (!erpResponse.ok) {
      throw new Error(`ERP responded with status: ${erpResponse.status}`);
    }

    const erpData = await erpResponse.json();
    const erpProducts = erpData.value || [];
    const erpProduct = erpProducts[0];

    if (!erpProduct) {
      return res.json({
        success: false,
        error: "No products found in ERP to test transformation"
      });
    }

    // Test transformation in both directions
    const toMongo = transformToMongoDB(erpProduct);

    // Create a mock MongoDB product for reverse transformation test
    const mockMongoProduct = {
      _id: '507f1f77bcf86cd799439011',
      productName: "Test Product",
      productPrice: "9.99",
      productDescription: "Test description"
    };
    const toERP = transformToERP(mockMongoProduct);

    res.json({
      success: true,
      originalERP: erpProduct,
      toMongoDB: toMongo,
      backToERP: toERP,
      transformationValid: !!(toERP.productID && toERP.name)
    });

  } catch (error) {
    console.error("Transform test failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ✅ Get sync status
app.get("/api/erp/sync-status", async (_req, res) => {
  try {
    const mongoCount = await Product.countDocuments();
    const mongoProducts = await Product.find().limit(5);

    let erpCount = 0;
    let erpProducts = [];
    let erpAvailable = false;

    try {
      const erpResponse = await fetch(ERP_PRODUCTS_API, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': ERP_AUTH_HEADER
        }
      });
      if (erpResponse.ok) {
        const erpData = await erpResponse.json();
        erpProducts = erpData.value || [];
        erpCount = erpProducts.length;
        erpAvailable = true;
      }
    } catch (erpError) {
      console.log("ERP status check failed:", erpError.message);
      erpAvailable = false;
    }

    const syncedProducts = await Product.countDocuments({
      erpProductId: { $exists: true, $ne: null }
    });

    res.json({
      success: true,
      data: {
        mongo: {
          count: mongoCount,
          synced: syncedProducts,
          sample: mongoProducts.map((p) => ({
            name: p.productName,
            price: p.productPrice,
            erpId: p.erpProductId || "Not Synced",
          })),
        },
        erp: {
          count: erpCount,
          sample: erpProducts.slice(0, 3).map((p) => ({
            id: p.ID || p.id,
            name: p.name || p.productName,
            price: p.price || p.productPrice,
            stock: p.stock || p.productStock, // Real-time stock from ERP
          })),
        },
        erpAvailable: erpAvailable,
        syncStatus: {
          syncFromERP: erpAvailable && mongoCount > 0,
          exportToERP: syncedProducts > 0,
        },
      },
    });
  } catch (error) {
    console.error("Status check failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// --- Authentication ---
app.post("/api/auth/register", async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: "Missing fields" });

  const passwordHash = await bcrypt.hash(password, 10);

  try {
    const user = await User.create({ email, passwordHash, name });
    const token = makeToken(user);
    res.json({
      token,
      user: { id: user._id, email: user.email, name: user.name },
    });
  } catch {
    res.status(400).json({ error: "Email already exists" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ error: "Invalid credentials" });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error: "Invalid credentials" });
  const token = makeToken(user);
  res.cookie("token", token, { httpOnly: true, sameSite: "lax" });
  res.json({
    token,
    user: { id: user._id, email: user.email, name: user.name },
  });
});

app.post("/api/auth/logout", (_req, res) => {
  res.clearCookie("token");
  res.json({ ok: true });
});

// ✅ GET Products from MongoDB
app.get("/api/products", async (_req, res) => {
  try {
    const products = await Product.find();

    const formatted = products.map((p) => ({
      _id: p._id,
      name: p.productName,
      price: Number(p.productPrice),
      description: p.productDescription,
      image:
        "https://via.placeholder.com/256?text=" +
        encodeURIComponent(p.productName),
    }));

    res.json({ success: true, data: formatted });
  } catch (error) {
    console.error("DB /products failed:", error.message);
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch products from DB" });
  }
});

// ✅ Orders saved in Mongo ONLY as reference
app.get("/api/orders/my", auth, async (req, res) => {
  const orders = await Order.find({ userId: req.user.uid })
    .sort({ createdAt: -1 })
    .lean();
  res.json(orders);
});

// ✅ REAL-TIME: Order creation with ERP as source of truth
app.post("/api/orders", auth, async (req, res) => {
  try {
    const itemsReq = Array.isArray(req.body.items) ? req.body.items : [];

    console.log("🛒 ORDER REQUEST DATA:", {
      items: itemsReq,
      user: req.user.uid,
    });

    if (!itemsReq.length) {
      return res.status(400).json({ error: "No items in order" });
    }

    // 🔹 NEW: load full user document
    const user = await User.findById(req.user.uid);
    if (!user) {
      return res.status(400).json({ error: "User not found" });
    }

    // 🔹 NEW: make sure this user has an ERP Customer and get its ID
    const erpCustomerId = await ensureERPCustomerForUser(user);

    // ✅ REAL-TIME STOCK VALIDATION FROM ERP
    const stockValidationErrors = [];

    for (const item of itemsReq) {
      try {
        const product = await Product.findById(item.productId);

        if (!product) {
          stockValidationErrors.push(`Product not found: ${item.productId}`);
          continue;
        }

        if (!product.erpProductId) {
          stockValidationErrors.push(
            `Product not synced with ERP: ${product.productName}`
          );
          continue;
        }

        const currentStock = await getERPStock(product.erpProductId);
        const requestedQty = item.qty || 0;

        if (currentStock < requestedQty) {
          const msg = `Insufficient stock for ${product.productName}: ${currentStock} available, ${requestedQty} requested`;
          stockValidationErrors.push(msg);

          // 🔸 Log “normal” out-of-stock as minor
          await logSystemError({
            tag: "minor",
            code: "OUT_OF_STOCK",
            message: msg,
            context: {
              productId: product._id,
              productName: product.productName,
              erpProductId: product.erpProductId,
              requestedQty,
              currentStock,
            },
          });
        }
      } catch (stockError) {
        const msg = `Stock check failed for product ID ${item.productId}: ${stockError.message}`;
        stockValidationErrors.push(msg);

        // 🔴 ERP / network problem while checking stock
        await logSystemError({
          tag: "critical",
          code: "STOCK_CHECK_FAILED",
          message: msg,
          context: {
            productId: item.productId,
            userId: req.user.uid,
          },
        });
      }
    }

    if (stockValidationErrors.length > 0) {
      return res.status(400).json({
        error: "Stock validation failed",
        details: stockValidationErrors,
      });
    }

    // ✅ CALCULATE TOTAL
    const total = itemsReq.reduce(
      (sum, item) => sum + (item.qty || 0) * (item.priceAtPurchase || 0),
      0
    );

    // ✅ CREATE ORDER DIRECTLY IN ERP FIRST
    let erpOrderResult;
    try {
      const orderData = {
        userId: req.user.uid,
        total: total,
        erpCustomerId: erpCustomerId, // 👈 now defined
      };

      erpOrderResult = await createERPOrder(orderData, itemsReq);

      if (!erpOrderResult.success) {
        throw new Error("ERP order creation failed");
      }
    } catch (erpOrderError) {
      console.error("❌ ERP Order creation failed:", erpOrderError);

      // Log critical ERP failure
      await logSystemError({
        tag: "critical",
        code: "ERP_ORDER_FAILURE",
        message: erpOrderError.message,
        context: {
          userId: req.user.uid,
          items: itemsReq,
          total,
        },
      });

      return res.status(500).json({
        error: "Failed to create order in ERP system",
        details: erpOrderError.message,
      });
    }

    // ✅ STORE ORDER REFERENCE IN MONGODB (NOT THE SOURCE OF TRUTH)
    const order = await Order.create({
      userId: req.user.uid,
      erpOrderId: erpOrderResult.orderId,
      items: itemsReq.map((i) => ({
        productId: String(i.productId),
        qty: i.qty,
        priceAtPurchase: i.priceAtPurchase,
      })),
      total,
      status: "created",
    });

    console.log(
      `✅ Order created successfully. ERP Order ID: ${erpOrderResult.orderId}`
    );

    // ✅ RESPOND TO FRONTEND
    res.status(201).json({
      ...order.toObject(),
      erpOrderId: erpOrderResult.orderId,
    });
  } catch (error) {
    console.error("❌ Checkout / create order failed:", error);

    // 🔥 Log unexpected backend error for this endpoint
    await logSystemError({
      tag: "critical",
      code: "ORDER_ENDPOINT_ERROR",
      message: error.message,
      context: {
        userId: req.user?.uid,
        body: req.body,
      },
    });

    res.status(500).json({ error: "Failed to create order" });
  }
});


// fetch product details
app.get("/api/product/fetchAllProducts", async (_req, res) => {
  try {
    const products = await Product.find({});
    res.json({
      success: true,
      msg: "Products fetched successfully",
      data: products
    });
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({
      success: false,
      msg: "Error fetching products",
      error: error.message
    });
  }
});

// delete product
app.delete("/api/product/deleteProduct/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        msg: "Product not found",
      });
    }

    // Delete from ERP first if it has ERP ID
    if (product.erpProductId) {
      try {
        await fetch(`${ERP_DELETE_PRODUCT_API}(${product.erpProductId}')`, {
          method: "DELETE",
          headers: {
            "Authorization": ERP_AUTH_HEADER
          }
        });
        console.log(`✅ Product deleted from ERP: ${product.productName}`);
      } catch (erpError) {
        console.warn(`⚠️ Product deleted from MongoDB but ERP delete failed: ${erpError.message}`);
      }
    }

    // Then delete from MongoDB
    await Product.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      msg: "Product deleted successfully",
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      msg: "Server error",
    });
  }
});

// =======================
// 🆕 REAL-TIME STOCK MANAGEMENT ENDPOINTS
// =======================

// ✅ REAL-TIME: Get stock for all products
// ✅ REAL-TIME: Get stock for all products
app.get("/api/stock", async (_req, res) => {
  try {
    const products = await Product.find({});
    const erpProductIds = products
      .map((p) => p.erpProductId)
      .filter((id) => id);

    const stockData = await getBulkERPStock(erpProductIds);

    const responseData = {};

    // IMPORTANT: detect transition >0 -> 0 and log it
    for (const product of products) {
      const erpId = product.erpProductId;
      const newStock = stockData[erpId] ?? 0;
      const oldStock = product.erpStock ?? 0;

      // 👇 this is the bit you were missing
      if (oldStock > 0 && newStock === 0) {
        await logSystemError({
          tag: "minor",
          code: "OUT_OF_STOCK",
          message: `Product '${product.productName}' is now out of stock`,
          context: {
            productId: product._id,
            erpProductId: erpId,
            oldStock,
            newStock,
          },
        });
      }

      // keep Mongo snapshot in sync so we don't log again next time
      if (oldStock !== newStock) {
        product.erpStock = newStock;
        await product.save();
      }

      responseData[product._id] = newStock;
    }

    res.json({
      success: true,
      data: responseData,
    });
  } catch (error) {
    console.error("❌ Error fetching real-time stock:", error);

    // 🔴 Log global stock-check failure for the list view
    await logSystemError({
      tag: "critical",
      code: "STOCK_CHECK_FAILED",
      message: `Global stock check failed: ${error.message}`,
      context: { endpoint: "/api/stock" },
    });

    res.status(500).json({
      success: false,
      error: "Failed to fetch real-time stock data",
    });
  }
});


// ✅ REAL-TIME: Get stock for specific product
app.get("/api/stock/:productId", async (req, res) => {
  try {
    const { productId } = req.params;
    const product = await Product.findById(productId);

    if (!product || !product.erpProductId) {
      return res.status(404).json({
        success: false,
        error: "Product not found or not synced with ERP"
      });
    }

    const stock = await getERPStock(product.erpProductId);

    res.json({
      success: true,
      data: {
        stock: stock,
        productName: product.productName
      }
    });
  } catch (error) {
    console.error("❌ Error fetching product stock:", error);

    await logSystemError({
      tag: "critical",
      code: "STOCK_CHECK_FAILED",
      message: `Product stock check failed: ${error.message}`,
      context: {
        endpoint: "/api/stock/:productId",
        productId: req.params.productId,
      },
    });

    res.status(500).json({
      success: false,
      error: "Failed to fetch real-time product stock",
    });
  }
});


// =======================
// NEW: Direct CSV to ERP Import (No MongoDB involved)
// =======================
app.post("/api/erp/csv-to-erp-direct", async (req, res) => {
  try {
    const { csvData, fileName = 'direct_upload.csv' } = req.body;

    console.log(`📤 Direct CSV to ERP import: ${fileName}`);

    if (!csvData) {
      return res.status(400).json({
        success: false,
        error: "No CSV data provided"
      });
    }

    // Parse CSV data
    const lines = csvData.split('\n').filter(line => line.trim());
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());

    console.log(`📊 CSV Headers: ${headers.join(', ')}`);
    console.log(`📊 Processing ${lines.length - 1} products for direct ERP creation`);

    let stats = {
      processed: 0,
      created: 0,
      errors: 0
    };
    const errors = [];
    const createdProducts = [];

    // Process each CSV row (skip header)
    for (let i = 1; i < lines.length; i++) {
      try {
        const line = lines[i];
        if (!line.trim()) continue;

        const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
        const productData = {};

        // Map CSV columns to product object
        headers.forEach((header, index) => {
          productData[header] = values[index] || '';
        });

        console.log(`🔄 Creating product in ERP: ${productData.name || 'Unknown'}`);

        // Transform to ERP format
        const erpProductData = {
          productID: `WEB_${(productData.name || 'PRODUCT').toUpperCase().replace(/\s+/g, '')}_${Date.now()}_${i}`,
          name: productData.name || 'New Product from CSV',
          description: productData.description || "Imported directly from CSV file",
          price: parseFloat(productData.price) || 0,
          stock: parseInt(productData.stock) || 0,
          currency_code: productData.currency || "EUR"
        };

        console.log("📤 Sending to ERP:", erpProductData);

        // Create directly in ERP
        const createResponse = await fetch(ERP_CREATE_PRODUCT_API, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": ERP_AUTH_HEADER
          },
          body: JSON.stringify(erpProductData),
        });

        if (createResponse.ok) {
          const erpResult = await createResponse.json();
          stats.created++;
          console.log(`✅ Created in ERP: ${erpProductData.name}`);

          createdProducts.push({
            name: erpProductData.name,
            erpId: erpResult.ID || erpResult.ProductID,
            price: erpProductData.price,
            stock: erpProductData.stock
          });
        } else {
          const errorText = await createResponse.text();
          throw new Error(`ERP creation failed: ${createResponse.status} - ${errorText}`);
        }

        stats.processed++;

      } catch (productError) {
        console.error(`❌ Error creating product from CSV line ${i}:`, productError.message);
        stats.errors++;
        errors.push({
          line: i,
          data: lines[i],
          error: productError.message
        });
      }
    }

    console.log(`✅ Direct CSV-to-ERP completed: ${stats.created} created, ${stats.errors} errors`);

    res.json({
      success: true,
      message: `Direct CSV to ERP import completed: ${stats.created} products created in ERP, ${stats.errors} errors`,
      stats: stats,
      createdProducts: createdProducts,
      errors: errors
    });

  } catch (error) {
    console.error("❌ Direct CSV to ERP failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      message: "Direct CSV to ERP import failed"
    });
  }
});

// =======================
// File Upload Endpoints for UI
// =======================

// Handle file upload from UI - CSV to ERP
app.post('/api/erp/upload-csv', upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: "No file uploaded"
      });
    }

    console.log(`📁 File uploaded: ${req.file.originalname}`);

    // Read the uploaded file
    const filePath = req.file.path;
    const csvData = fs.readFileSync(filePath, 'utf8');

    console.log("📊 Processing uploaded CSV file...");

    // Process the CSV data using your existing function
    const importResponse = await fetch(`http://localhost:${process.env.PORT || 5050}/api/erp/csv-to-erp-direct`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: req.file.originalname,
        csvData: csvData
      })
    });

    const result = await importResponse.json();

    // Clean up uploaded file
    fs.unlinkSync(filePath);

    res.json({
      success: true,
      message: `File processed successfully: ${result.message}`,
      originalFileName: req.file.originalname,
      importResults: result
    });

  } catch (error) {
    console.error("❌ File upload processing failed:", error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      message: "File upload processing failed"
    });
  }
});

// ✅ CSV to Database Upload (direct CSV → MongoDB using processProductsToDatabase)
app.post('/api/erp/upload-csv-to-db', upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: "No file uploaded"
      });
    }

    console.log("========== CSV→DB IMPORT START ==========");
    console.log(`📁 File name: ${req.file.originalname}`);

    const filePath = req.file.path;
    const csvData = fs.readFileSync(filePath, 'utf8');

    // Split lines, support both \n and \r\n, drop empty
    const lines = csvData.split(/\r?\n/).filter(l => l.trim().length > 0);

    if (lines.length < 2) {
      fs.unlinkSync(filePath);
      return res.status(400).json({
        success: false,
        error: "CSV file has no data rows"
      });
    }

    // Detect delimiter: comma or semicolon
    const headerLine = lines[0];
    const delimiter = headerLine.includes(";") && !headerLine.includes(",") ? ";" : ",";
    const headers = headerLine.split(delimiter).map(h => h.trim().replace(/^"|"$/g, ''));

    console.log("📊 Parsed headers:", headers);

    // Build array of "raw" product objects
    const products = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) continue;

      const values = line.split(delimiter)
        .map(v => v.trim().replace(/^"|"$/g, ''));

      const row = {};
      headers.forEach((header, idx) => {
        row[header] = values[idx] || "";
      });

      products.push(row);
    }

    console.log("📊 Total CSV data rows:", products.length);

    // 🔁 Use your new helper
    const { stats, importedProducts, errors } =
      await processProductsToDatabase(products);

    // Clean up temp file
    fs.unlinkSync(filePath);

    console.log("========== CSV→DB IMPORT DONE ==========");
    console.log("📊 Final stats:", stats);

    return res.json({
      success: true,
      message: `CSV to Database import completed: ${stats.created} created, ${stats.updated} updated, ${stats.errors} errors`,
      originalFileName: req.file.originalname,
      stats,
      importedProducts,
      errors
    });

  } catch (error) {
    console.error("❌ CSV to Database upload failed:", error);
    return res.status(500).json({
      success: false,
      error: error.message,
      message: "CSV to Database upload failed"
    });
  }
});

// ✅ COMPLETELY FIXED: Process Products to Database
async function processProductsToDatabase(products) {
  const importedProducts = [];
  let stats = {
    processed: 0,
    created: 0,
    updated: 0,
    errors: 0,
    total: products.length
  };
  const errors = [];

  for (const productData of products) {
    try {
      stats.processed++;
      
      console.log("🔄 RAW product data from file:", productData);

      // IMPROVED FIELD MAPPING - Handle all possible column name variations
      const name = productData.name || productData.productname || productData.product || 
                   productData.Name || productData.ProductName || productData['Product Name'] ||
                   productData['product name'] || productData.title || productData.Title ||
                   'Unknown Product';
      
      const description = productData.description || productData.productdescription || 
                         productData.Description || productData.ProductDescription || 
                         productData['Product Description'] || productData['product description'] ||
                         productData.desc || productData.Desc || productData.comment ||
                         'No description';
      
      // ✅ FIXED PRICE HANDLING - Remove currency symbols and clean
      let rawPrice = productData.price || productData.productprice || 
                     productData.Price || productData.ProductPrice || 
                     productData['Product Price'] || productData['product price'] ||
                     productData.cost || productData.Cost || productData.value ||
                     '0';

      console.log(`💰 Original price value: "${rawPrice}"`);

      // Clean the price - remove currency symbols, text, and non-numeric characters
      let cleanPrice = rawPrice.toString()
        .replace(/EUR|USD|€|\$|£|₹|¥|currency|currency_code|\\s+/gi, '')  // Remove currency symbols and text
        .replace(/[^\d.,-]/g, '')             // Remove non-numeric except . , -
        .replace(/,/g, '.')                   // Convert comma to decimal point
        .trim();

      // Handle empty prices
      if (!cleanPrice || cleanPrice === '.' || cleanPrice === '-') {
        cleanPrice = '0';
      }

      // Convert to number and ensure 2 decimal places
      const priceNum = parseFloat(cleanPrice);
      let finalPrice;
      if (isNaN(priceNum)) {
        console.warn(`⚠️ Price parsing failed for: "${rawPrice}" → "${cleanPrice}", using 0`);
        finalPrice = '0.00';
      } else {
        finalPrice = priceNum.toFixed(2); // Ensure 2 decimal places
      }

      console.log(`💰 Price conversion: "${rawPrice}" → "${finalPrice}"`);

      // ✅ FIXED STOCK HANDLING
      let rawStock = productData.stock || productData.productstock || 
                     productData.Stock || productData.ProductStock || 
                     productData['Product Stock'] || productData['product stock'] ||
                     productData.quantity || productData.Quantity || productData.qty ||
                     '0';
      
      // Clean stock value
      let cleanStock = rawStock.toString()
        .replace(/[^\d.-]/g, '')  // Remove non-numeric
        .trim();
      
      const stockNum = parseInt(cleanStock) || 0;
      const finalStock = String(Math.max(0, stockNum)); // Ensure non-negative

      console.log(`📦 Stock conversion: "${rawStock}" → "${finalStock}"`);

      // ✅ FIXED PRODUCT ID HANDLING
      const erpId = productData.id || productData.productid || productData.erpid || 
                    productData.ID || productData.ProductID || productData.erpProductId ||
                    productData['Product ID'] || productData['product id'] || 
                    productData['ERP ID'] || productData['erp id'] || productData.sku ||
                    productData.SKU || productData.code || productData.Code ||
                    null;

      const finalProductData = {
        productName: name,
        productDescription: description,
        productPrice: finalPrice, // Clean price without EUR
        productStock: finalStock,
        erpProductId: erpId
      };

      console.log("🎯 Final product to save:", finalProductData);

      // Validate we have at least a name
      if (name === 'Unknown Product') {
  console.log("❌ Available fields in this row:", Object.keys(productData));
  throw new Error('Product name could not be determined from file data. Available fields: ' + Object.keys(productData).join(', '));
}


      // ✅ IMPROVED PRODUCT MATCHING LOGIC
      let existingProduct = null;
      
      // Strategy 1: Match by ERP ID (most reliable)
      if (erpId) {
        existingProduct = await Product.findOne({ 
          erpProductId: { $regex: new RegExp(`^${erpId}$`, 'i') } 
        });
        if (existingProduct) {
          console.log(`🔍 Found existing product by ERP ID: ${erpId}`);
        }
      }
      
      // Strategy 2: Match by exact name (case insensitive)
      if (!existingProduct) {
        existingProduct = await Product.findOne({
          productName: { $regex: new RegExp(`^${name}$`, 'i') }
        });
        if (existingProduct) {
          console.log(`🔍 Found existing product by name: "${name}"`);
        }
      }
      
      // Strategy 3: Match by similar name (fuzzy matching for minor variations)
      if (!existingProduct) {
        const similarProducts = await Product.find({
          productName: { $regex: name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' }
        });
        if (similarProducts.length === 1) {
          existingProduct = similarProducts[0];
          console.log(`🔍 Found similar product: "${existingProduct.productName}" → "${name}"`);
        }
      }

      let status;
      let product;

      if (existingProduct) {
        // Check if anything actually changed
        const priceChanged = Number(existingProduct.productPrice) !== Number(finalPrice);
        const stockChanged = Number(existingProduct.productStock) !== Number(finalStock);
        const descChanged = existingProduct.productDescription !== description;
        
        if (priceChanged || stockChanged || descChanged) {
          console.log(`🔄 Updating: "${name}"`);
          if (priceChanged) console.log(`   Price: $${existingProduct.productPrice} → $${finalPrice}`);
          if (stockChanged) console.log(`   Stock: ${existingProduct.productStock} → ${finalStock}`);
          if (descChanged) console.log(`   Desc: ${existingProduct.productDescription} → ${description}`);
          
          product = await Product.findByIdAndUpdate(
            existingProduct._id, 
            finalProductData, 
            { new: true }
          );
          stats.updated++;
          status = 'updated';
        } else {
          console.log(`⏭️  No changes for: "${name}" - skipping`);
          stats.processed--; // Don't count as processed since no change
          continue;
        }
      } else {
        console.log(`🆕 Creating new product: "${name}"`);
        product = await Product.create(finalProductData);
        stats.created++;
        status = 'created';
      }

      importedProducts.push({
  productName: name,
  productPrice: finalPrice,
  productStock: finalStock,
  erpProductId: erpId,
  status: status,
  mongoId: product._id
});

      console.log(`✅ ${status.toUpperCase()}: ${name} - $${finalPrice} (Stock: ${finalStock})`);

    } catch (rowErr) {
      console.error(`❌ Error processing product:`, rowErr.message);
      console.error(`❌ Problematic data:`, productData);
      stats.errors++;
      errors.push({
        product: productData.name || 'Unknown',
        error: rowErr.message,
        rawData: productData
      });
    }
  }

  return { stats, importedProducts, errors };
}

// ✅ DEBUG: Check CSV structure and field mapping
app.post("/api/debug/check-csv", upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const filePath = req.file.path;
    const csvData = fs.readFileSync(filePath, 'utf8');
    
    const lines = csvData.split(/\r?\n/).filter(line => line.trim().length > 0);
    const headers = lines[0].split(',').map(h => h.trim());
    
    console.log("=== CSV STRUCTURE ANALYSIS ===");
    console.log("🔍 CSV HEADERS:", headers);
    console.log("📊 TOTAL ROWS:", lines.length - 1);
    
    // Show first 2 data rows with field mapping
    const sampleRows = [];
    for (let i = 1; i < Math.min(3, lines.length); i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
      const rowData = {};
      headers.forEach((header, index) => {
        rowData[header] = values[index] || '';
      });
      sampleRows.push(rowData);
      
      console.log(`📝 ROW ${i}:`, rowData);
      
      // Show what would be extracted
      const name = rowData.name || rowData.productname || rowData.product || 
                   rowData.Name || rowData.ProductName || rowData['Product Name'] ||
                   rowData['product name'] || 'Unknown Product';
      
      const price = rowData.price || rowData.productprice || 
                    rowData.Price || rowData.ProductPrice || 
                    rowData['Product Price'] || rowData['product price'] || '0';
      
      const erpId = rowData.id || rowData.productid || rowData.erpid || 
                    rowData.ID || rowData.ProductID || rowData.erpProductId ||
                    rowData['Product ID'] || rowData['product id'] || 
                    rowData['ERP ID'] || rowData['erp id'] || null;
      
      console.log(`   → Extracted: Name="${name}", Price="${price}", ERP ID="${erpId}"`);
    }

    fs.unlinkSync(filePath);

    res.json({
      success: true,
      headers: headers,
      sampleRows: sampleRows,
      totalRows: lines.length - 1,
      analysis: "Check server logs for detailed field mapping"
    });

  } catch (error) {
    console.error("Debug failed:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// =======================
// Server Start
// =======================
const PORT = process.env.PORT || 5050;
app.listen(PORT, () =>
  console.log(`🚀 Server running on http://localhost:${PORT}`)
);

console.log("✅ ERP as Single Source of Truth architecture enabled - Real-time RPC mode");
