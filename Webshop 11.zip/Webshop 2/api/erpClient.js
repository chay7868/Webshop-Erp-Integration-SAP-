// api/erpClient.js
const axios = require("axios");

// .env: ERP_BASE_URL=http://localhost:4004
const ERP_BASE_URL = process.env.ERP_BASE_URL || "http://localhost:4004";

// 👉 Fixed: Added the OData service path here
const ERP_ORDERS_URL = `${ERP_BASE_URL}/odata/v4/simple-erp/Orders`;
const ERP_CUSTOMERS_URL = `${ERP_BASE_URL}/odata/v4/simple-erp/Customers`;

const ERP_USERNAME = process.env.ERP_USERNAME || "alice";
const ERP_PASSWORD = process.env.ERP_PASSWORD || "alice";

const authConfig = {
  headers: {
    Authorization:
      "Basic " +
      Buffer.from(`${ERP_USERNAME}:${ERP_PASSWORD}`).toString("base64"),
    "Content-Type": "application/json",
    Accept: "application/json",
  },
};

/**
 * Find or create customer in ERP
 */
async function findOrCreateCustomer(user) {
  try {
    // Try to find existing customer by email
    const response = await axios.get(
      `${ERP_CUSTOMERS_URL}?$filter=email eq '${user.email}'`,
      authConfig
    );

    if (response.data.value && response.data.value.length > 0) {
      // Customer exists, return their ID
      return response.data.value[0].ID;
    }

    // Create new customer
    const newCustomer = {
      name: user.name,
      email: user.email,
      // Add other required fields if needed
      street: user.address?.street || "",
      city: user.address?.city || "",
      country_code: user.address?.country || "US" // default country
    };

    const createResponse = await axios.post(
      ERP_CUSTOMERS_URL,
      newCustomer,
      authConfig
    );

    console.log("✅ Created new customer in ERP:", createResponse.data);
    return createResponse.data.ID;

  } catch (err) {
    console.error("❌ Failed to find/create customer in ERP:", err.message);
    return null;
  }
}

/**
 * Send MongoDB Order to SAP simple-erp Orders.
 * @param {Object} order  - Mongo Order document
 * @param {Object} models - { User, Product } from server.js
 */
async function sendOrderToERP(order, { User, Product }) {
  try {
    const user = await User.findById(order.userId).lean();

    // 1️⃣ Find or create customer in ERP
    const customerId = await findOrCreateCustomer(user);
    
    if (!customerId) {
      console.warn("⚠️ Could not get customer ID from ERP. Skipping order sync.");
      return null;
    }

    // 2️⃣ Build OrderItems payload
    const erpItems = [];

    for (const item of order.items) {
      let product = null;

      // If productId is a Mongo ObjectId, try _id
      if (item.productId && item.productId.match(/^[0-9a-fA-F]{24}$/)) {
        product = await Product.findById(item.productId).lean();
      }

      // Fallback: frontend currently sends productName as productId
      if (!product) {
        product = await Product.findOne({
          productName: item.productId,
        }).lean();
      }

      if (!product) {
        console.warn("⚠️ Product not found for ERP item:", item.productId);
        continue;
      }

      if (!product.erpProductId) {
        console.warn(
          "⚠️ Product has no erpProductId, skipping:",
          product.productName
        );
        continue;
      }

      erpItems.push({
        // must match SimpleERPService.OrderItems/product_ID
        product_ID: product.erpProductId,
        quantity: item.qty,
        // SimpleERPService.OrderItems/itemAmount
        itemAmount: item.qty * item.priceAtPurchase,
        currency_code: "EUR",
      });
    }

    if (!erpItems.length) {
      console.warn("⚠️ No ERP-mappable items in order. Skipping ERP sync.");
      return null;
    }

    // 3️⃣ Orders header – INCLUDES CUSTOMER REFERENCE
    const payload = {
      // SimpleERPService.Orders/orderAmount
      orderAmount: order.total,
      // SimpleERPService.Orders/currency_code
      currency_code: "EUR",
      // Required field - use current date
      orderDate: new Date().toISOString().split('T')[0],
      // ✅ Reference to customer using navigation property
      customer_ID: customerId,
      // composition to OrderItems
      items: erpItems,
    };

    console.log("➡️ Sending order to ERP:");
    console.log("URL :", ERP_ORDERS_URL);
    console.log("Body:", JSON.stringify(payload, null, 2));
    console.log(
      "Customer (for log only):",
      `{ email: '${user?.email}', name: '${user?.name}', total: ${order.total} }`
    );

    const res = await axios.post(ERP_ORDERS_URL, payload, authConfig);

    console.log("✅ ERP order created:", res.data);

    // ⚠️ REMOVED: Stock synchronization - already handled in server.js
    
    return res.data;
  } catch (err) {
    console.error("❌ Failed to send order to ERP:");
    if (err.response) {
      console.error("URL   :", err.config?.url);
      console.error(
        "Status:",
        err.response.status,
        err.response.statusText || ""
      );
      console.error("Data  :", JSON.stringify(err.response.data, null, 2));
    } else {
      console.error("Error :", err.message);
    }
    return null;
  }
}

module.exports = { sendOrderToERP };