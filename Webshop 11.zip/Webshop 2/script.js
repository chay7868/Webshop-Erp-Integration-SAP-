// =======================
// CONFIG + GLOBAL STATE
// =======================
const API_BASE = "http://localhost:5050/api";

// DOM Elements
let searchForm = document.querySelector(".search-form");
let shoppingCart = document.querySelector(".shopping-cart");
let loginForm = document.querySelector(".login-form");
let registerForm = document.querySelector(".register-form");
let navbar = document.querySelector(".navbar");
let searchBox = document.querySelector("#search-box");

// ✅ Category Containers from HTML (3 sections)
const containerVeg = document.querySelectorAll(".products .box-container")[0];
const containerFruit = document.querySelectorAll(".products .box-container")[1];
const containerMeat = document.querySelectorAll(".products .box-container")[2];

// Application State
let products = []; // ✅ DB data here
let cart = JSON.parse(localStorage.getItem("cart")) || [];
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
let currentUser = JSON.parse(localStorage.getItem("currentUser")) || null;
let users = JSON.parse(localStorage.getItem("users")) || [];
let orders = JSON.parse(localStorage.getItem("orders")) || [];
let erpSyncStatus = { syncFromERP: false, exportToERP: false };

// small helper to set a status text area if present
function setERPStatus(text, type = "info") {
  const el = document.querySelector("#erp-status-text");
  if (el) {
    el.textContent = text;
    el.style.color =
      type === "success" ? "#0a7d25" : type === "error" ? "#b00020" : "#444";
  }
}

// =======================
// ✅ ERP SYNC MANAGEMENT
// =======================
async function loadERPSyncStatus() {
  try {
    setERPStatus("Checking status…");
    const res = await fetch(`${API_BASE}/erp/sync-status`);
    const json = await res.json();

    if (json.success) {
      erpSyncStatus = json.data.syncStatus;
      updateERPSyncUI();
      setERPStatus("Status ok", "success");
    } else {
      setERPStatus("Status check failed", "error");
    }
  } catch (err) {
    console.error("❌ Failed to load ERP sync status:", err);
    setERPStatus("Error Checking Status", "error");
  }
}

function updateERPSyncUI() {
  const syncFromCheckbox = document.querySelector("#sync-from-erp-checkbox");
  const exportToCheckbox = document.querySelector("#export-to-erp-checkbox");

  if (syncFromCheckbox) {
    syncFromCheckbox.checked = !!erpSyncStatus.syncFromERP;
    syncFromCheckbox.disabled = true;
  }

  if (exportToCheckbox) {
    exportToCheckbox.checked = !!erpSyncStatus.exportToERP;
    exportToCheckbox.disabled = true;
  }
}

async function syncFromERP() {
  try {
    showNotification("🔄 Syncing products from ERP...", "info");
    setERPStatus("Syncing…");

    const res = await fetch(`${API_BASE}/erp/sync-from-erp`);
    const json = await res.json();

    if (json.success) {
      showNotification(`✅ ${json.message}`, "success");
      setERPStatus("Sync from ERP complete", "success");
      await loadProductsFromDB();
      await loadERPSyncStatus();
    } else {
      showNotification(`❌ Sync failed: ${json.error || json.message}`, "error");
      setERPStatus("Sync failed", "error");
    }
  } catch (err) {
    console.error("❌ Sync from ERP failed:", err);
    showNotification("❌ Sync failed - check ERP connection", "error");
    setERPStatus("Sync failed", "error");
  }
}

async function exportToERP() {
  try {
    showNotification("📤 Exporting products to ERP...", "info");
    setERPStatus("Exporting…");

    const res = await fetch(`${API_BASE}/erp/export-to-erp`, { method: "POST" });
    const json = await res.json();

    if (json.success) {
      showNotification(`✅ ${json.message}`, "success");
      setERPStatus("Export complete", "success");
      await loadERPSyncStatus();

      // if backend returned per-item errors, show a readable summary
      if (Array.isArray(json.errors) && json.errors.length) {
        const details = json.errors
          .slice(0, 5)
          .map((e) => `• ${e.product}: ${e.error}`)
          .join("\n");
        showNotification(
          `Some items failed to export:\n${details}`,
          "error"
        );
      }
    } else {
      const msg = json.error || json.message || "Export failed";
      showNotification(`❌ Export failed: ${msg}`, "error");
      setERPStatus("Export failed", "error");
    }
  } catch (err) {
    console.error("❌ Export to ERP failed:", err);
    showNotification("❌ Export failed - check ERP connection", "error");
    setERPStatus("Export failed", "error");
  }
}

async function debugERPData() {
  try {
    setERPStatus("Fetching ERP raw data…");
    const res = await fetch(`${API_BASE}/erp/debug-products`);
    const json = await res.json();

    if (json.success) {
      setERPStatus(`ERP ok: ${json.productsCount} products`, "success");
      console.log("🔎 ERP RAW:", json.rawData);
      showNotification("ERP debug data fetched (see console)", "success");
    } else {
      showNotification(`Debug failed: ${json.error || json.message}`, "error");
      setERPStatus("Debug failed", "error");
    }
  } catch (err) {
    console.error("❌ Debug ERP Data failed:", err);
    showNotification("❌ Debug failed - check ERP connection", "error");
    setERPStatus("Debug failed", "error");
  }
}

async function refreshStatus() {
  await loadERPSyncStatus();
}

// =======================
// ✅ REAL-TIME STOCK MANAGEMENT - ERP AS SINGLE SOURCE OF TRUTH
// =======================
async function loadRealTimeStock() {
  try {
    console.log("🔄 Loading REAL-TIME stock data from ERP...");

    const response = await fetch(`${API_BASE}/stock`);
    const result = await response.json();

    console.log("📦 Real-time stock data received:", result);

    if (result.success && result.data) {
      updateStockDisplay(result.data);
    } else {
      console.error("❌ Real-time Stock API error:", result.error || result.message);
      // Fallback: show loading error
      showNotification("⚠️ Could not load current stock levels", "error");
    }
  } catch (error) {
    console.error("❌ Error loading real-time stock:", error);
    showNotification("❌ Failed to load stock - check ERP connection", "error");
  }
}

function updateStockDisplay(stockData) {
  console.log("🔄 Updating stock display with real-time data:", stockData);

  // Only real product cards that have a product-id from DB
  const productElements = document.querySelectorAll(
    ".products .box[data-product-id]"
  );

  console.log(`📦 Found ${productElements.length} product elements with IDs`);

  let updatedCount = 0;

  productElements.forEach((product) => {
    const productId = product.dataset.productId;
    const stockElement = product.querySelector(".stock-badge");
    if (!stockElement) return;

    const stockValue = stockData[productId];

    if (stockValue === undefined) {
      // No stock info for this product
      stockElement.textContent = "No stock info";
      stockElement.classList.remove("in-stock", "low-stock", "out-of-stock");
      stockElement.classList.add("out-of-stock");
      return;
    }

    updateStockStyling(stockElement, stockValue);
    updatedCount++;

    const productName = product.querySelector("h3")?.textContent?.trim();
    console.log(`✅ Updated "${productName}" stock to: ${stockValue}`);
  });

  console.log(`✅ Updated ${updatedCount} products with real-time stock data`);
}

function updateStockStyling(stockElement, stockValue) {
  const stockNum = parseInt(stockValue, 10);

  // Remove existing classes
  stockElement.classList.remove("in-stock", "low-stock", "out-of-stock");

  // Add appropriate class based on stock level
  if (stockNum === 0) {
    stockElement.textContent = "Out of Stock";
    stockElement.classList.add("out-of-stock");
  } else if (stockNum <= 5) {
    stockElement.textContent = `Low Stock: ${stockNum}`;
    stockElement.classList.add("low-stock");
  } else {
    stockElement.textContent = `In Stock: ${stockNum}`;
    stockElement.classList.add("in-stock");
  }
}

// Initialize real-time stock system when page loads
function initializeRealTimeStockSystem() {
  console.log("🔄 Initializing REAL-TIME stock system...");

  // Load stock immediately
  loadRealTimeStock();

  // Refresh stock more frequently (every 15 seconds) for real-time updates
  setInterval(loadRealTimeStock, 15000);

  console.log("✅ Real-time Stock management initialized");
}

// Also add a manual refresh function
function refreshStock() {
  console.log("🔄 Manually refreshing real-time stock...");
  loadRealTimeStock();
}

// =======================
// ✅ REAL-TIME STOCK VALIDATION FOR CART
// =======================
async function validateCartStock() {
  try {
    console.log("🔄 Validating cart items against real-time ERP stock...");
    
    const validationPromises = cart.map(async (item) => {
      try {
        // Get product details to find ERP ID
        const product = products.find(p => p.name === item.name);
        if (!product || !product.id) {
          return { item, valid: false, error: "Product not found" };
        }

        // Check real-time stock from ERP
        const response = await fetch(`${API_BASE}/stock/${product.id}`);
        const result = await response.json();

        if (result.success) {
          const availableStock = result.data.stock;
          if (availableStock < item.quantity) {
            return { 
              item, 
              valid: false, 
              error: `Only ${availableStock} available` 
            };
          }
          return { item, valid: true };
        } else {
          return { item, valid: false, error: "Stock check failed" };
        }
      } catch (error) {
        console.error(`❌ Stock validation failed for ${item.name}:`, error);
        return { item, valid: false, error: "Validation error" };
      }
    });

    const results = await Promise.all(validationPromises);
    const invalidItems = results.filter(result => !result.valid);
    
    return {
      allValid: invalidItems.length === 0,
      invalidItems: invalidItems
    };
  } catch (error) {
    console.error("❌ Cart stock validation failed:", error);
    return { allValid: false, invalidItems: [], error: "Validation system error" };
  }
}

// =======================
// ✅ Fetch Products from DB and Render UI
// =======================
async function loadProductsFromDB() {
  try {
    const res = await fetch(`${API_BASE}/product/fetchAllProducts`);
    const json = await res.json();

    const fallbackImg =
      "https://cdn-icons-png.flaticon.com/512/1046/1046765.png";

    products = (json.data || []).map((p) => {
      const id = p._id || p.productId || p.erpId || p.id;
      return {
        id,
        name: p.productName,
        category: (p.productDescription || "").toLowerCase(),
        price: Number(p.productPrice),
        // Note: No stock information - we get this real-time from ERP
        image: fallbackImg,
        erpProductId: p.erpProductId // Keep ERP reference
      };
    });

    renderProducts();
    setupAddToCartButtons();

    console.log("✅ Database products loaded:", products);
  } catch (err) {
    console.error("❌ Failed to fetch DB products:", err);
  }
}

// ✅ Display dynamic MongoDB products
function renderProducts() {
  containerVeg.innerHTML = "";
  containerFruit.innerHTML = "";
  containerMeat.innerHTML = "";

  products.forEach((product) => {
    const card = `
      <div class="box" data-category="${product.category}" data-product-id="${
      product.id || ""
    }" data-erp-product-id="${product.erpProductId || ""}">
        <img src="${product.image}">
        <h3>${product.name}</h3>
        <div class="price">$${product.price}/-</div>
        <div class="stock-info">
          <span class="stock-badge in-stock">Checking stock...</span>
        </div>
        <div class="stars">
          <i class="fas fa-star"></i><i class="fas fa-star"></i>
          <i class="fas fa-star"></i><i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <a href="#" class="btn add-to-cart">add to cart</a>
      </div>
    `;

    if (product.category === "vegetables") {
      containerVeg.insertAdjacentHTML("beforeend", card);
    } else if (product.category === "fruits") {
      containerFruit.insertAdjacentHTML("beforeend", card);
    } else if (product.category === "meat") {
      containerMeat.insertAdjacentHTML("beforeend", card);
    }
  });
}

// INIT APP
document.addEventListener("DOMContentLoaded", async function () {
  // 1️⃣ Load products from DB first so .box[data-product-id] exists
  await loadProductsFromDB();

  // 2️⃣ Now initialize REAL-TIME stock system so it can attach to the rendered products
  initializeRealTimeStockSystem();

  // 3️⃣ Rest of initialization
  loadERPSyncStatus(); // Load ERP sync status
  initializeApp();
  initializeSwipers();
  setupSearchFunctionality();
});

// =======================
// UI + EVENTS + SEARCH + LOGIN + CART + ORDERS
// =======================
function initializeApp() {
  // Check if user is already logged in via backend token
  const token = localStorage.getItem("token");
  const storedUser = localStorage.getItem("currentUser");

  if (token && storedUser) {
    try {
      currentUser = JSON.parse(storedUser);
      isLoggedIn = true;
    } catch (e) {
      console.error("Error parsing stored user:", e);
      // Clear invalid data
      localStorage.removeItem("token");
      localStorage.removeItem("currentUser");
      localStorage.setItem("isLoggedIn", "false");
    }
  }

  setupEventListeners();
  updateCartDisplay();
  updateUserInterface();
  updateOrdersCount();
}

function setupEventListeners() {
  document.querySelector("#search-btn").onclick = () => toggleUI("search");
  document.querySelector("#cart-btn").onclick = () => toggleUI("cart");
  document.querySelector("#login-btn").onclick = () => handleLoginButtonClick();
  document.querySelector("#menu-btn").onclick = () => toggleUI("menu");

  const ordersBtn = document.querySelector("#orders-btn");
  if (ordersBtn) {
    ordersBtn.onclick = (e) => {
      e.preventDefault();
      handleOrdersClick();
    };
  }

  const checkoutBtn = document.querySelector("#checkout-btn");
  if (checkoutBtn) {
    checkoutBtn.onclick = (e) => {
      e.preventDefault();
      handleCheckout();
    };
  }

  // ERP Sync buttons
  const syncFromBtn = document.querySelector("#sync-from-erp-btn");
  if (syncFromBtn) {
    syncFromBtn.onclick = (e) => {
      e.preventDefault();
      syncFromERP();
    };
  }

  const exportToBtn = document.querySelector("#export-to-erp-btn");
  if (exportToBtn) {
    exportToBtn.onclick = (e) => {
      e.preventDefault();
      exportToERP();
    };
  }

  const debugBtn = document.querySelector("#debug-erp-btn");
  if (debugBtn) {
    debugBtn.onclick = (e) => {
      e.preventDefault();
      debugERPData();
    };
  }

  const refreshBtn = document.querySelector("#refresh-status-btn");
  if (refreshBtn) {
    refreshBtn.onclick = (e) => {
      e.preventDefault();
      refreshStatus();
    };
  }

  if (loginForm) loginForm.onsubmit = (e) => handleLogin(e);
  if (registerForm) registerForm.onsubmit = (e) => handleRegister(e);

  const showReg = document.querySelector("#show-register");
  if (showReg) {
    showReg.onclick = (e) => {
      e.preventDefault();
      showRegisterForm();
    };
  }

  const showLogin = document.querySelector("#show-login");
  if (showLogin) {
    showLogin.onclick = (e) => {
      e.preventDefault();
      showLoginForm();
    };
  }

  setupAddToCartButtons();
  window.onscroll = closeAllUI;
}

function handleLoginButtonClick() {
  if (isLoggedIn) logout();
  else toggleUI("login");
}

function toggleUI(type) {
  closeAllUI();
  switch (type) {
    case "search":
      searchForm.classList.toggle("active");
      break;
    case "cart":
      shoppingCart.classList.toggle("active");
      updateCartDisplay();
      break;
    case "login":
      loginForm.classList.toggle("active");
      break;
    case "menu":
      navbar.classList.toggle("active");
      break;
  }
}

function closeAllUI() {
  if (searchForm) searchForm.classList.remove("active");
  if (shoppingCart) shoppingCart.classList.remove("active");
  if (loginForm) loginForm.classList.remove("active");
  if (registerForm) registerForm.classList.remove("active");
  if (navbar) navbar.classList.remove("active");
  hideSearchResults();
}

// =======================
// ✅ SEARCH SYSTEM
// =======================
function setupSearchFunctionality() {
  if (!searchBox) return;
  searchBox.addEventListener("input", searchProducts);
  searchBox.addEventListener("focus", showSearchResults);
  document.addEventListener("click", (e) => {
    if (!searchForm || !searchForm.contains(e.target)) hideSearchResults();
  });
}

function searchProducts() {
  const searchTerm = searchBox.value.toLowerCase().trim();
  const searchResults = document.getElementById("search-results");
  if (!searchResults) return;

  if (!searchTerm) return hideSearchResults();

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm) ||
      p.category.toLowerCase().includes(searchTerm)
  );

  if (filteredProducts.length === 0) {
    searchResults.innerHTML = `<div class="no-results">No products found</div>`;
  } else {
    searchResults.innerHTML = filteredProducts
      .map(
        (product) => `
      <div class="search-result-item" onclick="addProductToCart('${product.name}')">
        <img src="${product.image}">
        <div><h4>${product.name}</h4><span>$${product.price}</span></div>
      </div>
    `
      )
      .join("");
  }

  searchResults.style.display = "block";
}

function hideSearchResults() {
  const el = document.getElementById("search-results");
  if (el) el.style.display = "none";
}

function showSearchResults() {
  if (searchBox.value) searchProducts();
}

// =======================
// ✅ FIXED: Add to Cart System (No Duplicates)
// =======================
function setupAddToCartButtons() {
  // Remove any existing event listeners first
  document.removeEventListener("click", handleAddToCartClick);

  // Add single event listener with proper event delegation
  document.addEventListener("click", handleAddToCartClick);
}

function handleAddToCartClick(e) {
  if (e.target.classList.contains("add-to-cart")) {
    e.preventDefault();
    e.stopPropagation(); // Prevent event bubbling

    const productCard = e.target.closest(".box");
    if (!productCard) return;

    const productName = productCard
      .querySelector("h3")
      .textContent.trim()
      .toLowerCase();
    const priceText = productCard.querySelector(".price").textContent;

    // Extract price (handle both formats: "$2.99/-" and "$2.99/- - 5.99/-")
    const priceMatch = priceText.match(/\$([\d.]+)/);
    const price = priceMatch ? parseFloat(priceMatch[1]) : 0;

    const product = products.find((p) => p.name.toLowerCase() === productName);

    if (product) {
      addToCart(product);
    } else {
      // Fallback: create product from card data
      const fallbackProduct = {
        name: productCard.querySelector("h3").textContent.trim(),
        price: price,
        image: productCard.querySelector("img").src,
        category: productCard.dataset.category || "unknown",
      };
      addToCart(fallbackProduct);
    }
  }
}

// ✅ IMPROVED: Add to Cart function with real-time stock check
async function addToCart(product) {
  // Validate product
  if (!product || !product.name) {
    console.error("Invalid product:", product);
    return;
  }

  // Check real-time stock before adding to cart
  try {
    if (product.id) {
      const response = await fetch(`${API_BASE}/stock/${product.id}`);
      const result = await response.json();
      
      if (result.success) {
        const availableStock = result.data.stock;
        const existingItem = cart.find((i) => i.name === product.name);
        const currentQty = existingItem ? existingItem.quantity : 0;
        
        if (availableStock <= currentQty) {
          showNotification(`❌ Sorry, only ${availableStock} ${product.name} available in stock`, "error");
          return;
        }
      }
    }
  } catch (error) {
    console.error("❌ Stock check failed:", error);
    // Continue with add to cart even if stock check fails
  }

  // ✅ FIX: Use MongoDB _id instead of name
const existing = cart.find((i) => i.id === product.id);

if (existing) {
  existing.quantity += 1;
} else {
  cart.push({
    id: product.id,        // ✅ Use MongoDB _id
    productId: product.id, // ✅ Also include as productId for backend
    name: product.name,
    price: product.price,
    image: product.image,
    quantity: 1,
  });
}

  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartDisplay();
  showNotification(`${product.name} added to cart!`, "success");
}

// Remove From Cart
function removeFromCart(index) {
  if (index >= 0) {
    const removed = cart[index];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartDisplay();
    showNotification(`${removed.name} removed!`, "success");
  }
}

// Cart UI Update
function updateCartDisplay() {
  const cartItems = document.querySelector(".cart-items");
  const totalElement = document.querySelector(".shopping-cart .total");
  if (!cartItems || !totalElement) return;

  cartItems.innerHTML = "";
  let total = 0;

  if (cart.length === 0) {
    cartItems.innerHTML = '<div class="empty-cart">Your cart is empty</div>';
  } else {
    cart.forEach((item, index) => {
      total += item.price * item.quantity;
      cartItems.insertAdjacentHTML(
        "beforeend",
        `
        <div class="box">
          <i class="fas fa-trash" onclick="removeFromCart(${index})"></i>
          <img src="${item.image}">
          <div class="content">
            <h3>${item.name}</h3>
            <span class="price">$${item.price}/-</span>
            <span class="quantity">qty : ${item.quantity}</span>
          </div>
        </div>
      `
      );
    });
  }

  totalElement.textContent = `total : $${total.toFixed(2)}/-`;
  updateCartCount();
}

function updateCartCount() {
  const cartBtn = document.querySelector("#cart-btn");
  if (!cartBtn) return;

  const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
  let badge = cartBtn.querySelector(".cart-count");

  if (!badge) {
    badge = document.createElement("span");
    badge.className = "cart-count";
    cartBtn.appendChild(badge);
  }

  badge.style.display = totalQty > 0 ? "flex" : "none";
  badge.textContent = totalQty;
}

// =======================
// ✅ LOGIN / REGISTER (FIXED - Uses Backend API)
// =======================
async function handleLogin(e) {
  if (e) e.preventDefault();

  const email = document.querySelector("#login-email")?.value;
  const password = document.querySelector("#login-password")?.value;

  if (!email || !password) return showNotification("Missing fields", "error");

  try {
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    if (response.ok) {
      // Store token and user data
      localStorage.setItem("token", data.token);
      localStorage.setItem("currentUser", JSON.stringify(data.user));
      localStorage.setItem("isLoggedIn", "true");

      login(data.user);
    } else {
      showNotification(data.error || "Login failed", "error");
    }
  } catch (error) {
    console.error("Login error:", error);
    showNotification("Network error - please try again", "error");
  }
}

async function handleRegister(e) {
  if (e) e.preventDefault();

  const name = document.querySelector("#register-name")?.value;
  const email = document.querySelector("#register-email")?.value;
  const password = document.querySelector("#register-password")?.value;
  const confirm = document.querySelector("#register-confirm")?.value;

  if (!name || !email || !password)
    return showNotification("Fill all fields!", "error");
  if (password !== confirm)
    return showNotification("Passwords don't match!", "error");

  try {
    const response = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, password }),
    });

    const data = await response.json();

    if (response.ok) {
      // Store token and user data
      localStorage.setItem("token", data.token);
      localStorage.setItem("currentUser", JSON.stringify(data.user));
      localStorage.setItem("isLoggedIn", "true");

      login(data.user);
      showNotification("Registered ✅", "success");
    } else {
      showNotification(data.error || "Registration failed", "error");
    }
  } catch (error) {
    console.error("Registration error:", error);
    showNotification("Network error - please try again", "error");
  }
}

function login(user) {
  isLoggedIn = true;
  currentUser = user;

  closeAllUI();
  updateUserInterface();
  updateOrdersCount();
  if (loginForm) loginForm.reset();
  if (registerForm) registerForm.reset();
  showNotification("Welcome back! ✅", "success");
}

function logout() {
  // Call backend logout if needed
  fetch(`${API_BASE}/auth/logout`, { method: "POST" }).catch(console.error);

  // Clear local storage
  isLoggedIn = false;
  currentUser = null;
  localStorage.removeItem("token");
  localStorage.removeItem("currentUser");
  localStorage.setItem("isLoggedIn", "false");

  updateUserInterface();
  updateOrdersCount();
  showNotification("Logged out!", "success");
}

function showRegisterForm() {
  if (loginForm) loginForm.classList.remove("active");
  if (registerForm) registerForm.classList.add("active");
}

function showLoginForm() {
  if (registerForm) registerForm.classList.remove("active");
  if (loginForm) loginForm.classList.add("active");
}

function updateUserInterface() {
  const loginBtn = document.querySelector("#login-btn i");
  if (!loginBtn) return;
  loginBtn.className = isLoggedIn ? "fas fa-sign-out-alt" : "fas fa-user";
}

// =======================
// ✅ ORDERS
// =======================
function updateOrdersCount() {
  const ordersBtn = document.querySelector("#orders-btn");
  if (!ordersBtn || !isLoggedIn) return;

  const userOrders = orders.filter((order) => order.userId === currentUser?.id);
  let badge = ordersBtn.querySelector(".orders-count");

  if (!badge) {
    badge = document.createElement("span");
    badge.className = "orders-count";
    ordersBtn.appendChild(badge);
  }

  if (userOrders.length > 0) {
    badge.textContent = userOrders.length;
    badge.style.display = "flex";
  } else {
    badge.style.display = "none";
  }
}

function handleOrdersClick() {
  if (!isLoggedIn) {
    showNotification("Please login to view your orders", "error");
    if (loginForm) loginForm.classList.add("active");
    return;
  }

  // ✅ go to the dedicated orders page
  window.location.href = "orders.html";
}

function showOrdersPage() {
  const userOrders = orders.filter((order) => order.userId === currentUser.id);

  if (userOrders.length === 0) {
    showNotification("You have no orders yet!", "error");
    return;
  }

  let ordersContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>My Orders - FreshGrocer</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .order-container { max-width: 800px; margin: 0 auto; }
        .order-card { background: white; padding: 20px; margin-bottom: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .order-header { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .order-number { font-weight: bold; font-size: 18px; }
        .order-date { color: #666; }
        .order-status { padding: 5px 10px; border-radius: 15px; font-weight: bold; }
        .status-processing { background: #fff3cd; color: #856404; }
        .order-items { margin-top: 15px; }
        .order-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
        .order-total { text-align: right; font-weight: bold; font-size: 18px; margin-top: 15px; }
        h1 { text-align: center; color: #333; }
      </style>
    </head>
    <body>
      <div class="order-container">
        <h1>My Orders</h1>
  `;

  userOrders.forEach((order) => {
    ordersContent += `
      <div class="order-card">
        <div class="order-header">
          <div>
            <div class="order-number">Order #${order.orderNumber}</div>
            <div class="order-date">${order.date}</div>
          </div>
          <div class="order-status status-processing">${order.status}</div>
        </div>
        <div class="order-items">
          ${order.items
            .map(
              (item) => `
            <div class="order-item">
              <span>${item.name} (x${item.quantity})</span>
              <span>$${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          `
            )
            .join("")}
        </div>
        <div class="order-total">Total: $${order.total.toFixed(2)}</div>
      </div>
    `;
  });

  ordersContent += `
      </div>
    </body>
    </html>
  `;

  const ordersWindow = window.open("", "_blank", "width=900,height=700");
  ordersWindow.document.write(ordersContent);
  ordersWindow.document.close();
}

// =======================
// ✅ REAL-TIME CHECKOUT WITH ERP VALIDATION
// =======================
async function handleCheckout() {
  if (!isLoggedIn) {
    showNotification("Please login to checkout", "error");
    if (loginForm) loginForm.classList.add("active");
    if (shoppingCart) shoppingCart.classList.remove("active");
    return;
  }

  if (cart.length === 0) {
    showNotification("Your cart is empty", "error");
    return;
  }

  try {
    // ✅ REAL-TIME STOCK VALIDATION BEFORE CHECKOUT
    showNotification("🔄 Checking stock availability...", "info");
    
    const stockValidation = await validateCartStock();
    
    if (!stockValidation.allValid) {
      const errorMessages = stockValidation.invalidItems
        .map(invalid => `• ${invalid.item.name}: ${invalid.error}`)
        .join('\n');
      
      showNotification(
        `❌ Stock issues found:\n${errorMessages}`,
        "error"
      );
      return;
    }

    const token = localStorage.getItem("token");

    // ✅ Prepare order data for ERP
    // ✅ CORRECT - Use MongoDB ID
const orderData = {
  items: cart.map((item) => ({
    productId: item.id, // ✅ Use MongoDB _id
    qty: item.quantity,
    priceAtPurchase: item.price,
  })),
};

    console.log("Sending order data to ERP:", orderData);

    const response = await fetch(`${API_BASE}/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(orderData),
    });

    if (response.ok) {
      const order = await response.json();

      // Clear cart after successful order
      cart = [];
      localStorage.setItem("cart", JSON.stringify(cart));
      updateCartDisplay();
      updateOrdersCount();

      showNotification("Order placed successfully! ✅", "success");
      if (shoppingCart) shoppingCart.classList.remove("active");

      // Show order confirmation with ERP order ID
      showOrderSuccessMessage(order);
      
      // Refresh stock display to show updated quantities
      loadRealTimeStock();
    } else {
      const errorData = await response.json();
      console.error("Checkout failed:", errorData);
      showNotification(
        `Checkout failed: ${errorData.error || "Please try again"}`,
        "error"
      );
    }
  } catch (error) {
    console.error("Checkout error:", error);
    showNotification("Checkout failed - network error", "error");
  }
}

// ✅ Add this function if missing
function showOrderSuccessMessage(order) {
  const orderNumber = order.erpOrderId || (order._id ? order._id.slice(-6) : "N/A");
  const message = `
    <div style="text-align: center; padding: 20px;">
      <h3 style="color: green;">🎉 Order Placed Successfully!</h3>
      <p>ERP Order #${orderNumber}</p>
      <p>Thank you for your purchase!</p>
    </div>
  `;

  showNotification("Order placed successfully! ✅", "success");
}

// =======================
// ✅ NOTIFICATION SYSTEM
// =======================
function showNotification(message, type = "success") {
  const existing = document.querySelectorAll(".notification");
  existing.forEach((n) => n.remove());

  const notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    if (notification.parentNode) notification.remove();
  }, 3000);
}

// =======================
// ✅ SWIPER INIT
// =======================
function initializeSwipers() {
  if (document.querySelector(".review-slider")) {
    try {
      new Swiper(".review-slider", {
        loop: true,
        spaceBetween: 20,
        autoplay: { delay: 6000, disableOnInteraction: false },
        centeredSlides: true,
        breakpoints: {
          0: { slidesPerView: 1 },
          768: { slidesPerView: 2 },
          1020: { slidesPerView: 3 },
        },
        pagination: { el: ".swiper-pagination", clickable: true },
      });
    } catch (error) {
      console.log("Review slider initialization error:", error);
    }
  }
}

// ✅ ADD THIS FUNCTION TO YOUR script.js
async function testERPConnection() {
  try {
    console.log("🔄 Testing ERP connection...");

    // Test backend connection
    const healthRes = await fetch(`${API_BASE}/health`);
    console.log("✅ Backend connection:", healthRes.ok);

    // Test ERP connection
    const erpHealthRes = await fetch(`${API_BASE}/erp/health`);
    const erpHealth = await erpHealthRes.json();
    console.log("✅ ERP connection:", erpHealth.ok);

    if (erpHealth.ok) {
      console.log(
        `✅ ERP has ${erpHealth.productsCount || "unknown"} products available`
      );
    } else {
      console.log("❌ ERP connection failed:", erpHealth.error);
    }
  } catch (err) {
    console.error("❌ Connection test failed:", err);
  }
}

// =======================
// ✅ EXTRA HELPERS
// =======================
function addProductToCart(productName) {
  const product = products.find((p) => p.name === productName);
  if (product) {
    addToCart(product);
    hideSearchResults();
    if (searchBox) searchBox.value = "";
    showNotification(`${product.name} added to cart!`, "success");
  }
}

// Filter demo (unchanged)
function filterProducts(category) {
  const boxes = document.querySelectorAll(".products .box");
  boxes.forEach((box) => {
    if (category === "all" || box.dataset.category === category) {
      box.style.display = "block";
    } else {
      box.style.display = "none";
    }
  });
}

// =======================
// ✅ GLOBALS
// =======================
window.removeFromCart = removeFromCart;
window.addProductToCart = addProductToCart;
window.filterProducts = filterProducts;
window.logout = logout;
window.showRegisterForm = showRegisterForm;
window.showLoginForm = showLoginForm;
window.syncFromERP = syncFromERP;
window.exportToERP = exportToERP;
window.debugERPData = debugERPData;
window.refreshStatus = refreshStatus;
window.refreshStock = refreshStock;
window.testERPConnection = testERPConnection;